/*
 Navicat Premium Data Transfer

 Source Server         : huawei
 Source Server Type    : MySQL
 Source Server Version : 80024
 Source Host           : 124.70.100.65:3306
 Source Schema         : go-admin-prd

 Target Server Type    : MySQL
 Target Server Version : 80024
 File Encoding         : 65001

 Date: 18/05/2022 11:42:03
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for content_announcement
-- ----------------------------
DROP TABLE IF EXISTS `content_announcement`;
CREATE TABLE `content_announcement` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '内容',
  `num` int DEFAULT NULL COMMENT '阅读次数',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注信息',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '0' COMMENT '状态（0正常 1删除 2停用 3冻结）',
  `create_by` int NOT NULL COMMENT '创建者',
  `update_by` int NOT NULL COMMENT '更新者',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_sys_content_create_by` (`create_by`),
  KEY `idx_sys_content_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='公告管理';

-- ----------------------------
-- Records of content_announcement
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for content_article
-- ----------------------------
DROP TABLE IF EXISTS `content_article`;
CREATE TABLE `content_article` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `cate_id` bigint DEFAULT NULL COMMENT '分类编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '名称',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '内容',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注信息',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '0' COMMENT '状态（0正常 1删除 2停用 3冻结）',
  `create_by` int NOT NULL COMMENT '创建者',
  `update_by` int NOT NULL COMMENT '更新者',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_sys_content_create_by` (`create_by`),
  KEY `idx_sys_content_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='文章管理';

-- ----------------------------
-- Records of content_article
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for content_category
-- ----------------------------
DROP TABLE IF EXISTS `content_category`;
CREATE TABLE `content_category` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '名称',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '0' COMMENT '状态（0正常 1删除 2停用 3冻结）',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注信息',
  `create_by` int NOT NULL COMMENT '创建者',
  `update_by` int NOT NULL COMMENT '更新者',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_sys_category_create_by` (`create_by`),
  KEY `idx_sys_category_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='文章分类管理';

-- ----------------------------
-- Records of content_category
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for filemgr_app
-- ----------------------------
DROP TABLE IF EXISTS `filemgr_app`;
CREATE TABLE `filemgr_app` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `version` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '版本号',
  `platform` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '平台 ( 0:安卓 1:苹果 )',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '版本(0:中文版 1:英文版  2:运营商版)',
  `local_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '本地地址',
  `bucket_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'bucketName，用于生成下载链接',
  `oss_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用于生成下载链接',
  `download_num` decimal(10,0) DEFAULT '0' COMMENT '下载数量',
  `download_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '下载类型(0-oss 1-外链)',
  `download_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '下载地址(download_type=1使用)',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注信息',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '状态（0正常 1删除 2停用 3冻结）',
  `create_by` int NOT NULL COMMENT '创建者',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `update_by` int NOT NULL COMMENT '更新者',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='app升级管理';

-- ----------------------------
-- Records of filemgr_app
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_api
-- ----------------------------
DROP TABLE IF EXISTS `sys_api`;
CREATE TABLE `sys_api` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `handle` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'handle',
  `title` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '标题',
  `path` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '地址',
  `type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '接口类型',
  `action` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '请求类型',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`id`),
  KEY `idx_sys_api_create_by` (`create_by`),
  KEY `idx_sys_api_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_api
-- ----------------------------
BEGIN;
INSERT INTO `sys_api` VALUES (1, 'go-admin/app/admin/apis.GoAdmin', '', '/', '', 'GET', '2022-05-18 11:19:31.358', '2022-05-18 11:19:31.358', 0, 0);
INSERT INTO `sys_api` VALUES (2, 'go-admin/app/admin/apis/tools.SysTable.GetSysTablesInfo-fm', '', '/admin-api/v1/sys/tables/info', '', 'GET', '2022-05-18 11:19:31.583', '2022-05-18 11:19:31.583', 0, 0);
INSERT INTO `sys_api` VALUES (3, 'go-admin/app/admin/apis/tools.SysTable.Get-fm', '', '/admin-api/v1/sys/tables/info/:tableId', '', 'GET', '2022-05-18 11:19:31.802', '2022-05-18 11:19:31.802', 0, 0);
INSERT INTO `sys_api` VALUES (4, 'go-admin/app/admin/apis/tools.SysTable.GetPage-fm', '', '/admin-api/v1/sys/tables/page', '', 'GET', '2022-05-18 11:19:32.051', '2022-05-18 11:19:32.051', 0, 0);
INSERT INTO `sys_api` VALUES (5, 'go-admin/app/admin/apis.SysDept.GetPage-fm', '', '/admin-api/v1/sys/dept', '', 'GET', '2022-05-18 11:19:32.274', '2022-05-18 11:19:32.274', 0, 0);
INSERT INTO `sys_api` VALUES (6, 'go-admin/app/admin/apis.SysDept.Get-fm', '', '/admin-api/v1/sys/dept/:id', '', 'GET', '2022-05-18 11:19:32.487', '2022-05-18 11:19:32.487', 0, 0);
INSERT INTO `sys_api` VALUES (7, 'go-admin/app/admin/apis.SysDept.Get2Tree-fm', '', '/admin-api/v1/sys/deptTree', '', 'GET', '2022-05-18 11:19:32.695', '2022-05-18 11:19:32.695', 0, 0);
INSERT INTO `sys_api` VALUES (8, 'go-admin/app/admin/apis.SysPost.GetPage-fm', '', '/admin-api/v1/sys/post', '', 'GET', '2022-05-18 11:19:32.895', '2022-05-18 11:19:32.895', 0, 0);
INSERT INTO `sys_api` VALUES (9, 'go-admin/app/admin/apis.SysPost.Export-fm', '', '/admin-api/v1/sys/post/export', '', 'GET', '2022-05-18 11:19:33.097', '2022-05-18 11:19:33.097', 0, 0);
INSERT INTO `sys_api` VALUES (10, 'go-admin/app/admin/apis.SysPost.Get-fm', '', '/admin-api/v1/sys/post/:id', '', 'GET', '2022-05-18 11:19:33.427', '2022-05-18 11:19:33.427', 0, 0);
INSERT INTO `sys_api` VALUES (11, 'go-admin/app/admin/apis.SysMenu.GetMenuTreeSelect-fm', '', '/admin-api/v1/sys/roleMenuTreeselect/:roleId', '', 'GET', '2022-05-18 11:19:33.648', '2022-05-18 11:19:33.648', 0, 0);
INSERT INTO `sys_api` VALUES (12, 'go-admin/app/admin/apis.SysDept.GetDeptTreeRoleSelect-fm', '', '/admin-api/v1/sys/roleDeptTreeselect/:roleId', '', 'GET', '2022-05-18 11:19:33.882', '2022-05-18 11:19:33.882', 0, 0);
INSERT INTO `sys_api` VALUES (13, 'go-admin/app/admin/apis.SysApi.GetPage-fm', '', '/admin-api/v1/sys-api', '', 'GET', '2022-05-18 11:19:34.131', '2022-05-18 11:19:34.131', 0, 0);
INSERT INTO `sys_api` VALUES (14, 'go-admin/app/admin/apis.SysApi.Export-fm', '', '/admin-api/v1/sys-api/export', '', 'GET', '2022-05-18 11:19:34.401', '2022-05-18 11:19:34.401', 0, 0);
INSERT INTO `sys_api` VALUES (15, 'go-admin/app/admin/apis.SysApi.Get-fm', '', '/admin-api/v1/sys-api/:id', '', 'GET', '2022-05-18 11:19:34.630', '2022-05-18 11:19:34.630', 0, 0);
INSERT INTO `sys_api` VALUES (16, 'go-admin/app/admin/apis.SysLoginLog.GetPage-fm', '', '/admin-api/v1/sys-login-log', '', 'GET', '2022-05-18 11:19:34.853', '2022-05-18 11:19:34.853', 0, 0);
INSERT INTO `sys_api` VALUES (17, 'go-admin/app/admin/apis.SysLoginLog.Export-fm', '', '/admin-api/v1/sys-login-log/export', '', 'GET', '2022-05-18 11:19:35.080', '2022-05-18 11:19:35.080', 0, 0);
INSERT INTO `sys_api` VALUES (18, 'go-admin/app/admin/apis.SysLoginLog.Get-fm', '', '/admin-api/v1/sys-login-log/:id', '', 'GET', '2022-05-18 11:19:35.273', '2022-05-18 11:19:35.273', 0, 0);
INSERT INTO `sys_api` VALUES (19, 'go-admin/app/admin/apis.SysOperaLog.GetPage-fm', '', '/admin-api/v1/sys-opera-log', '', 'GET', '2022-05-18 11:19:35.471', '2022-05-18 11:19:35.471', 0, 0);
INSERT INTO `sys_api` VALUES (20, 'go-admin/app/admin/apis.SysOperaLog.Export-fm', '', '/admin-api/v1/sys-opera-log/export', '', 'GET', '2022-05-18 11:19:35.690', '2022-05-18 11:19:35.690', 0, 0);
INSERT INTO `sys_api` VALUES (21, 'go-admin/app/admin/apis.SysOperaLog.Get-fm', '', '/admin-api/v1/sys-opera-log/:id', '', 'GET', '2022-05-18 11:19:35.900', '2022-05-18 11:19:35.900', 0, 0);
INSERT INTO `sys_api` VALUES (22, 'go-admin/app/admin/apis.SysUser.GetPage-fm', '', '/admin-api/v1/sys-user', '', 'GET', '2022-05-18 11:19:36.115', '2022-05-18 11:19:36.115', 0, 0);
INSERT INTO `sys_api` VALUES (23, 'go-admin/app/admin/apis.SysUser.Get-fm', '', '/admin-api/v1/sys-user/:id', '', 'GET', '2022-05-18 11:19:36.327', '2022-05-18 11:19:36.327', 0, 0);
INSERT INTO `sys_api` VALUES (24, 'go-admin/app/admin/apis.SysRuntimeConfig.GetConfig-fm', '', '/admin-api/v1/sysRuntimeConfig/getConfig', '', 'GET', '2022-05-18 11:19:36.543', '2022-05-18 11:19:36.543', 0, 0);
INSERT INTO `sys_api` VALUES (25, 'go-admin/app/admin/apis.ServerMonitor.ServerInfo-fm', '', '/admin-api/v1/server-monitor', '', 'GET', '2022-05-18 11:19:36.755', '2022-05-18 11:19:36.755', 0, 0);
INSERT INTO `sys_api` VALUES (26, 'go-admin/app/plugins/content/apis.Announcement.GetPage-fm', '', '/admin-api/v1/content/announcement', '', 'GET', '2022-05-18 11:19:36.982', '2022-05-18 11:19:36.982', 0, 0);
INSERT INTO `sys_api` VALUES (27, 'go-admin/app/plugins/content/apis.Announcement.Export-fm', '', '/admin-api/v1/content/announcement/export', '', 'GET', '2022-05-18 11:19:37.191', '2022-05-18 11:19:37.191', 0, 0);
INSERT INTO `sys_api` VALUES (28, 'go-admin/app/plugins/content/apis.Announcement.Get-fm', '', '/admin-api/v1/content/announcement/:id', '', 'GET', '2022-05-18 11:19:37.398', '2022-05-18 11:19:37.398', 0, 0);
INSERT INTO `sys_api` VALUES (29, 'go-admin/app/plugins/content/apis.Article.GetPage-fm', '', '/admin-api/v1/content/article', '', 'GET', '2022-05-18 11:19:37.607', '2022-05-18 11:19:37.607', 0, 0);
INSERT INTO `sys_api` VALUES (30, 'go-admin/app/plugins/content/apis.Article.Export-fm', '', '/admin-api/v1/content/article/export', '', 'GET', '2022-05-18 11:19:37.815', '2022-05-18 11:19:37.815', 0, 0);
INSERT INTO `sys_api` VALUES (31, 'go-admin/app/plugins/content/apis.Article.Get-fm', '', '/admin-api/v1/content/article/:id', '', 'GET', '2022-05-18 11:19:38.018', '2022-05-18 11:19:38.018', 0, 0);
INSERT INTO `sys_api` VALUES (32, 'go-admin/app/plugins/content/apis.Category.GetPage-fm', '', '/admin-api/v1/content/category', '', 'GET', '2022-05-18 11:19:38.226', '2022-05-18 11:19:38.226', 0, 0);
INSERT INTO `sys_api` VALUES (33, 'go-admin/app/plugins/content/apis.Category.Export-fm', '', '/admin-api/v1/content/category/export', '', 'GET', '2022-05-18 11:19:38.438', '2022-05-18 11:19:38.438', 0, 0);
INSERT INTO `sys_api` VALUES (34, 'go-admin/app/plugins/content/apis.Category.Get-fm', '', '/admin-api/v1/content/category/:id', '', 'GET', '2022-05-18 11:19:38.644', '2022-05-18 11:19:38.644', 0, 0);
INSERT INTO `sys_api` VALUES (35, 'go-admin/app/admin/apis.SysConfig.GetPage-fm', '', '/admin-api/v1/config', '', 'GET', '2022-05-18 11:19:38.847', '2022-05-18 11:19:38.847', 0, 0);
INSERT INTO `sys_api` VALUES (36, 'go-admin/app/admin/apis.SysConfig.Export-fm', '', '/admin-api/v1/config/export', '', 'GET', '2022-05-18 11:19:39.048', '2022-05-18 11:19:39.048', 0, 0);
INSERT INTO `sys_api` VALUES (37, 'go-admin/app/admin/apis.SysConfig.Get-fm', '', '/admin-api/v1/config/:id', '', 'GET', '2022-05-18 11:19:39.275', '2022-05-18 11:19:39.275', 0, 0);
INSERT INTO `sys_api` VALUES (38, 'go-admin/app/admin/apis.SysConfig.GetSysConfigByKEYForService-fm', '', '/admin-api/v1/configKey/:configKey', '', 'GET', '2022-05-18 11:19:39.502', '2022-05-18 11:19:39.502', 0, 0);
INSERT INTO `sys_api` VALUES (39, 'go-admin/app/admin/apis.System.GenerateCaptchaHandler-fm', '', '/admin-api/v1/captcha', '', 'GET', '2022-05-18 11:19:39.723', '2022-05-18 11:19:39.723', 0, 0);
INSERT INTO `sys_api` VALUES (40, 'go-admin/app/admin/apis.SysDictType.GetPage-fm', '', '/admin-api/v1/dict/type', '', 'GET', '2022-05-18 11:19:39.931', '2022-05-18 11:19:39.931', 0, 0);
INSERT INTO `sys_api` VALUES (41, 'go-admin/app/admin/apis.SysDictType.Export-fm', '', '/admin-api/v1/dict/type/export', '', 'GET', '2022-05-18 11:19:40.141', '2022-05-18 11:19:40.141', 0, 0);
INSERT INTO `sys_api` VALUES (42, 'go-admin/app/admin/apis.SysDictType.Get-fm', '', '/admin-api/v1/dict/type/:id', '', 'GET', '2022-05-18 11:19:40.344', '2022-05-18 11:19:40.344', 0, 0);
INSERT INTO `sys_api` VALUES (43, 'go-admin/app/admin/apis.SysDictType.GetAll-fm', '', '/admin-api/v1/dict/type-option-select', '', 'GET', '2022-05-18 11:19:40.547', '2022-05-18 11:19:40.547', 0, 0);
INSERT INTO `sys_api` VALUES (44, 'go-admin/app/admin/apis.SysDictData.GetPage-fm', '', '/admin-api/v1/dict/data', '', 'GET', '2022-05-18 11:19:40.762', '2022-05-18 11:19:40.762', 0, 0);
INSERT INTO `sys_api` VALUES (45, 'go-admin/app/admin/apis.SysDictData.Export-fm', '', '/admin-api/v1/dict/data/export', '', 'GET', '2022-05-18 11:19:40.987', '2022-05-18 11:19:40.987', 0, 0);
INSERT INTO `sys_api` VALUES (46, 'go-admin/app/admin/apis.SysDictData.Get-fm', '', '/admin-api/v1/dict/data/:dictCode', '', 'GET', '2022-05-18 11:19:41.195', '2022-05-18 11:19:41.195', 0, 0);
INSERT INTO `sys_api` VALUES (47, 'go-admin/app/admin/apis.SysDictData.GetSysDictDataAll-fm', '', '/admin-api/v1/dict-data/option-select', '', 'GET', '2022-05-18 11:19:41.386', '2022-05-18 11:19:41.386', 0, 0);
INSERT INTO `sys_api` VALUES (48, 'go-admin/app/admin/apis/tools.(*Gen).GetDBTableList-fm', '', '/admin-api/v1/db/tables/page', '', 'GET', '2022-05-18 11:19:41.571', '2022-05-18 11:19:41.571', 0, 0);
INSERT INTO `sys_api` VALUES (49, 'go-admin/app/admin/apis/tools.(*Gen).GetDBColumnList-fm', '', '/admin-api/v1/db/columns/page', '', 'GET', '2022-05-18 11:19:41.811', '2022-05-18 11:19:41.811', 0, 0);
INSERT INTO `sys_api` VALUES (50, 'go-admin/app/admin/apis/tools.Gen.GenCode-fm', '', '/admin-api/v1/gen/toproject/:tableId', '', 'GET', '2022-05-18 11:19:42.031', '2022-05-18 11:19:42.031', 0, 0);
INSERT INTO `sys_api` VALUES (51, 'go-admin/app/admin/apis/tools.Gen.GenMenuAndApi-fm', '', '/admin-api/v1/gen/todb/:tableId', '', 'GET', '2022-05-18 11:19:42.323', '2022-05-18 11:19:42.323', 0, 0);
INSERT INTO `sys_api` VALUES (52, 'go-admin/app/admin/apis/tools.SysTable.GetSysTablesTree-fm', '', '/admin-api/v1/gen/tabletree', '', 'GET', '2022-05-18 11:19:42.573', '2022-05-18 11:19:42.573', 0, 0);
INSERT INTO `sys_api` VALUES (53, 'go-admin/app/admin/apis/tools.Gen.Preview-fm', '', '/admin-api/v1/gen/preview/:tableId', '', 'GET', '2022-05-18 11:19:42.791', '2022-05-18 11:19:42.791', 0, 0);
INSERT INTO `sys_api` VALUES (54, 'go-admin/app/admin/apis/tools.Gen.DownloadCode-fm', '', '/admin-api/v1/gen/downloadCode/:tableId', '', 'GET', '2022-05-18 11:19:42.993', '2022-05-18 11:19:42.993', 0, 0);
INSERT INTO `sys_api` VALUES (55, 'go-admin/app/admin/apis.SysUser.GetInfo-fm', '', '/admin-api/v1/getinfo', '', 'GET', '2022-05-18 11:19:43.203', '2022-05-18 11:19:43.203', 0, 0);
INSERT INTO `sys_api` VALUES (56, 'go-admin/app/admin/apis.SysMenu.GetPage-fm', '', '/admin-api/v1/menu', '', 'GET', '2022-05-18 11:19:43.400', '2022-05-18 11:19:43.400', 0, 0);
INSERT INTO `sys_api` VALUES (57, 'go-admin/app/admin/apis.SysMenu.Get-fm', '', '/admin-api/v1/menu/:id', '', 'GET', '2022-05-18 11:19:43.591', '2022-05-18 11:19:43.591', 0, 0);
INSERT INTO `sys_api` VALUES (58, 'go-admin/app/admin/apis.SysMenu.GetMenuRole-fm', '', '/admin-api/v1/menurole', '', 'GET', '2022-05-18 11:19:43.803', '2022-05-18 11:19:43.803', 0, 0);
INSERT INTO `sys_api` VALUES (59, 'go-admin/common/core/tools/transfer.Handler.func1', '', '/admin-api/v1/metrics', '', 'GET', '2022-05-18 11:19:43.999', '2022-05-18 11:19:43.999', 0, 0);
INSERT INTO `sys_api` VALUES (60, 'go-admin/app/plugins/filemgr/apis.App.GetPage-fm', '', '/admin-api/v1/filemgr/app', '', 'GET', '2022-05-18 11:19:44.216', '2022-05-18 11:19:44.216', 0, 0);
INSERT INTO `sys_api` VALUES (61, 'go-admin/app/plugins/filemgr/apis.App.Export-fm', '', '/admin-api/v1/filemgr/app/export', '', 'GET', '2022-05-18 11:19:44.431', '2022-05-18 11:19:44.431', 0, 0);
INSERT INTO `sys_api` VALUES (62, 'go-admin/app/plugins/filemgr/apis.App.Get-fm', '', '/admin-api/v1/filemgr/app/:id', '', 'GET', '2022-05-18 11:19:44.635', '2022-05-18 11:19:44.635', 0, 0);
INSERT INTO `sys_api` VALUES (63, 'go-admin/app/admin/apis.SysRole.GetPage-fm', '', '/admin-api/v1/role', '', 'GET', '2022-05-18 11:19:44.835', '2022-05-18 11:19:44.835', 0, 0);
INSERT INTO `sys_api` VALUES (64, 'go-admin/app/admin/apis.SysRole.Get-fm', '', '/admin-api/v1/role/:id', '', 'GET', '2022-05-18 11:19:45.035', '2022-05-18 11:19:45.035', 0, 0);
INSERT INTO `sys_api` VALUES (65, 'go-admin/app/admin/router.registerMonitorRouter.func1', '', '/admin-api/v1/health', '', 'GET', '2022-05-18 11:19:45.247', '2022-05-18 11:19:45.247', 0, 0);
INSERT INTO `sys_api` VALUES (66, 'go-admin/app/admin/apis.SysConfig.GetSysConfigBySysApp-fm', '', '/admin-api/v1/app-config', '', 'GET', '2022-05-18 11:19:45.435', '2022-05-18 11:19:45.435', 0, 0);
INSERT INTO `sys_api` VALUES (67, 'go-admin/app/admin/apis.SysUser.GetProfile-fm', '', '/admin-api/v1/user/profile', '', 'GET', '2022-05-18 11:19:45.653', '2022-05-18 11:19:45.653', 0, 0);
INSERT INTO `sys_api` VALUES (68, 'go-admin/common/core/sdk/pkg/ws.(*Manager).WsClient-fm', '', '/ws/:id/:channel', '', 'GET', '2022-05-18 11:19:45.863', '2022-05-18 11:19:45.863', 0, 0);
INSERT INTO `sys_api` VALUES (69, 'go-admin/common/core/sdk/pkg/ws.(*Manager).UnWsClient-fm', '', '/wslogout/:id/:channel', '', 'GET', '2022-05-18 11:19:46.067', '2022-05-18 11:19:46.067', 0, 0);
INSERT INTO `sys_api` VALUES (70, 'go-admin/app/admin/router.Ping', '', '/info', '', 'GET', '2022-05-18 11:19:46.275', '2022-05-18 11:19:46.275', 0, 0);
INSERT INTO `sys_api` VALUES (71, 'github.com/gin-gonic/gin.(*RouterGroup).createStaticHandler.func1', '', '/tmp/*filepath', '', 'GET', '2022-05-18 11:19:46.479', '2022-05-18 11:19:46.479', 0, 0);
INSERT INTO `sys_api` VALUES (72, 'github.com/gin-gonic/gin.(*RouterGroup).createStaticHandler.func1', '', '/static/*filepath', '', 'GET', '2022-05-18 11:19:46.683', '2022-05-18 11:19:46.683', 0, 0);
INSERT INTO `sys_api` VALUES (73, 'github.com/gin-gonic/gin.(*RouterGroup).createStaticHandler.func1', '', '/form-generator/*filepath', '', 'GET', '2022-05-18 11:19:46.887', '2022-05-18 11:19:46.887', 0, 0);
INSERT INTO `sys_api` VALUES (74, 'github.com/gin-gonic/gin.(*RouterGroup).createStaticHandler.func1', '', '/static/*filepath', '', 'HEAD', '2022-05-18 11:19:47.091', '2022-05-18 11:19:47.091', 0, 0);
INSERT INTO `sys_api` VALUES (75, 'github.com/gin-gonic/gin.(*RouterGroup).createStaticHandler.func1', '', '/form-generator/*filepath', '', 'HEAD', '2022-05-18 11:19:47.295', '2022-05-18 11:19:47.295', 0, 0);
INSERT INTO `sys_api` VALUES (76, 'go-admin/app/admin/apis/tools.SysTable.Insert-fm', '', '/admin-api/v1/sys/tables/info', '', 'POST', '2022-05-18 11:19:47.503', '2022-05-18 11:19:47.503', 0, 0);
INSERT INTO `sys_api` VALUES (77, 'go-admin/app/admin/apis.SysDept.Insert-fm', '', '/admin-api/v1/sys/dept', '', 'POST', '2022-05-18 11:19:47.712', '2022-05-18 11:19:47.712', 0, 0);
INSERT INTO `sys_api` VALUES (78, 'go-admin/app/admin/apis.SysPost.Insert-fm', '', '/admin-api/v1/sys/post', '', 'POST', '2022-05-18 11:19:47.952', '2022-05-18 11:19:47.952', 0, 0);
INSERT INTO `sys_api` VALUES (79, 'go-admin/app/admin/apis.SysUser.Insert-fm', '', '/admin-api/v1/sys-user', '', 'POST', '2022-05-18 11:19:48.159', '2022-05-18 11:19:48.159', 0, 0);
INSERT INTO `sys_api` VALUES (80, 'go-admin/app/plugins/content/apis.Announcement.Insert-fm', '', '/admin-api/v1/content/announcement', '', 'POST', '2022-05-18 11:19:48.359', '2022-05-18 11:19:48.359', 0, 0);
INSERT INTO `sys_api` VALUES (81, 'go-admin/app/plugins/content/apis.Article.Insert-fm', '', '/admin-api/v1/content/article', '', 'POST', '2022-05-18 11:19:48.563', '2022-05-18 11:19:48.563', 0, 0);
INSERT INTO `sys_api` VALUES (82, 'go-admin/app/plugins/content/apis.Category.Insert-fm', '', '/admin-api/v1/content/category', '', 'POST', '2022-05-18 11:19:48.767', '2022-05-18 11:19:48.767', 0, 0);
INSERT INTO `sys_api` VALUES (83, 'go-admin/app/admin/apis.SysConfig.Insert-fm', '', '/admin-api/v1/config', '', 'POST', '2022-05-18 11:19:48.991', '2022-05-18 11:19:48.991', 0, 0);
INSERT INTO `sys_api` VALUES (84, 'go-admin/app/admin/apis.SysUser.Login-fm', '', '/admin-api/v1/login', '', 'POST', '2022-05-18 11:19:49.205', '2022-05-18 11:19:49.205', 0, 0);
INSERT INTO `sys_api` VALUES (85, 'go-admin/app/admin/apis.(*SysUser).LogOut-fm', '', '/admin-api/v1/logout', '', 'POST', '2022-05-18 11:19:49.423', '2022-05-18 11:19:49.423', 0, 0);
INSERT INTO `sys_api` VALUES (86, 'go-admin/app/admin/apis.SysDictData.Insert-fm', '', '/admin-api/v1/dict/data', '', 'POST', '2022-05-18 11:19:49.632', '2022-05-18 11:19:49.632', 0, 0);
INSERT INTO `sys_api` VALUES (87, 'go-admin/app/admin/apis.SysDictType.Insert-fm', '', '/admin-api/v1/dict/type', '', 'POST', '2022-05-18 11:19:49.879', '2022-05-18 11:19:49.879', 0, 0);
INSERT INTO `sys_api` VALUES (88, 'go-admin/app/plugins/filemgr/apis.App.Insert-fm', '', '/admin-api/v1/filemgr/app', '', 'POST', '2022-05-18 11:19:50.083', '2022-05-18 11:19:50.083', 0, 0);
INSERT INTO `sys_api` VALUES (89, 'go-admin/app/plugins/filemgr/apis.App.Upload-fm', '', '/admin-api/v1/filemgr/app/upload', '', 'POST', '2022-05-18 11:19:50.288', '2022-05-18 11:19:50.288', 0, 0);
INSERT INTO `sys_api` VALUES (90, 'go-admin/app/admin/apis.File.UploadFile-fm', '', '/admin-api/v1/public/uploadFile', '', 'POST', '2022-05-18 11:19:50.514', '2022-05-18 11:19:50.514', 0, 0);
INSERT INTO `sys_api` VALUES (91, 'go-admin/app/admin/apis.SysMenu.Insert-fm', '', '/admin-api/v1/menu', '', 'POST', '2022-05-18 11:19:50.727', '2022-05-18 11:19:50.727', 0, 0);
INSERT INTO `sys_api` VALUES (92, 'go-admin/app/admin/apis.SysRole.Insert-fm', '', '/admin-api/v1/role', '', 'POST', '2022-05-18 11:19:50.930', '2022-05-18 11:19:50.930', 0, 0);
INSERT INTO `sys_api` VALUES (93, 'go-admin/app/admin/apis.SysUser.InsetAvatar-fm', '', '/admin-api/v1/user/avatar', '', 'POST', '2022-05-18 11:19:51.150', '2022-05-18 11:19:51.150', 0, 0);
INSERT INTO `sys_api` VALUES (94, 'go-admin/app/admin/apis.SysUser.Update-fm', '', '/admin-api/v1/sys-user', '', 'PUT', '2022-05-18 11:19:51.378', '2022-05-18 11:19:51.378', 0, 0);
INSERT INTO `sys_api` VALUES (95, 'go-admin/app/admin/apis.SysUser.UpdateSelfEmail-fm', '', '/admin-api/v1/sys-user/updateSelfEmail', '', 'PUT', '2022-05-18 11:19:51.579', '2022-05-18 11:19:51.579', 0, 0);
INSERT INTO `sys_api` VALUES (96, 'go-admin/app/admin/apis.SysUser.UpdateSelfPhone-fm', '', '/admin-api/v1/sys-user/updateSelfPhone', '', 'PUT', '2022-05-18 11:19:51.783', '2022-05-18 11:19:51.783', 0, 0);
INSERT INTO `sys_api` VALUES (97, 'go-admin/app/admin/apis.SysUser.UpdateSelfNickName-fm', '', '/admin-api/v1/sys-user/updateSelfNickName', '', 'PUT', '2022-05-18 11:19:51.987', '2022-05-18 11:19:51.987', 0, 0);
INSERT INTO `sys_api` VALUES (98, 'go-admin/app/admin/apis.SysApi.Update-fm', '', '/admin-api/v1/sys-api/:id', '', 'PUT', '2022-05-18 11:19:52.182', '2022-05-18 11:19:52.182', 0, 0);
INSERT INTO `sys_api` VALUES (99, 'go-admin/app/admin/apis/tools.SysTable.Update-fm', '', '/admin-api/v1/sys/tables/info', '', 'PUT', '2022-05-18 11:19:52.385', '2022-05-18 11:19:52.385', 0, 0);
INSERT INTO `sys_api` VALUES (100, 'go-admin/app/admin/apis.SysDept.Update-fm', '', '/admin-api/v1/sys/dept/:id', '', 'PUT', '2022-05-18 11:19:52.594', '2022-05-18 11:19:52.594', 0, 0);
INSERT INTO `sys_api` VALUES (101, 'go-admin/app/admin/apis.SysPost.Update-fm', '', '/admin-api/v1/sys/post/:id', '', 'PUT', '2022-05-18 11:19:52.812', '2022-05-18 11:19:52.812', 0, 0);
INSERT INTO `sys_api` VALUES (102, 'go-admin/app/plugins/content/apis.Announcement.Update-fm', '', '/admin-api/v1/content/announcement/:id', '', 'PUT', '2022-05-18 11:19:53.011', '2022-05-18 11:19:53.011', 0, 0);
INSERT INTO `sys_api` VALUES (103, 'go-admin/app/plugins/content/apis.Article.Update-fm', '', '/admin-api/v1/content/article/:id', '', 'PUT', '2022-05-18 11:19:53.199', '2022-05-18 11:19:53.199', 0, 0);
INSERT INTO `sys_api` VALUES (104, 'go-admin/app/plugins/content/apis.Category.Update-fm', '', '/admin-api/v1/content/category/:id', '', 'PUT', '2022-05-18 11:19:53.402', '2022-05-18 11:19:53.402', 0, 0);
INSERT INTO `sys_api` VALUES (105, 'go-admin/app/admin/apis.SysConfig.Update-fm', '', '/admin-api/v1/config/:id', '', 'PUT', '2022-05-18 11:19:53.639', '2022-05-18 11:19:53.639', 0, 0);
INSERT INTO `sys_api` VALUES (106, 'go-admin/app/admin/apis.SysRole.Update-fm', '', '/admin-api/v1/role/:id', '', 'PUT', '2022-05-18 11:19:53.939', '2022-05-18 11:19:53.939', 0, 0);
INSERT INTO `sys_api` VALUES (107, 'go-admin/app/admin/apis.SysRole.Update2Status-fm', '', '/admin-api/v1/role-status', '', 'PUT', '2022-05-18 11:19:54.195', '2022-05-18 11:19:54.195', 0, 0);
INSERT INTO `sys_api` VALUES (108, 'go-admin/app/admin/apis.SysRole.Update2DataScope-fm', '', '/admin-api/v1/roledatascope', '', 'PUT', '2022-05-18 11:19:54.423', '2022-05-18 11:19:54.423', 0, 0);
INSERT INTO `sys_api` VALUES (109, 'go-admin/app/admin/apis.SysDictData.Update-fm', '', '/admin-api/v1/dict/data/:dictCode', '', 'PUT', '2022-05-18 11:19:54.647', '2022-05-18 11:19:54.647', 0, 0);
INSERT INTO `sys_api` VALUES (110, 'go-admin/app/admin/apis.SysDictType.Update-fm', '', '/admin-api/v1/dict/type/:id', '', 'PUT', '2022-05-18 11:19:54.855', '2022-05-18 11:19:54.855', 0, 0);
INSERT INTO `sys_api` VALUES (111, 'go-admin/app/admin/apis.SysUser.UpdatePwd-fm', '', '/admin-api/v1/user/pwd/set', '', 'PUT', '2022-05-18 11:19:55.043', '2022-05-18 11:19:55.043', 0, 0);
INSERT INTO `sys_api` VALUES (112, 'go-admin/app/admin/apis.SysUser.ResetPwd-fm', '', '/admin-api/v1/user/pwd/reset', '', 'PUT', '2022-05-18 11:19:55.251', '2022-05-18 11:19:55.251', 0, 0);
INSERT INTO `sys_api` VALUES (113, 'go-admin/app/admin/apis.SysMenu.Update-fm', '', '/admin-api/v1/menu/:id', '', 'PUT', '2022-05-18 11:19:55.451', '2022-05-18 11:19:55.451', 0, 0);
INSERT INTO `sys_api` VALUES (114, 'go-admin/app/plugins/filemgr/apis.App.Update-fm', '', '/admin-api/v1/filemgr/app/:id', '', 'PUT', '2022-05-18 11:19:55.655', '2022-05-18 11:19:55.655', 0, 0);
INSERT INTO `sys_api` VALUES (115, 'go-admin/app/admin/apis/tools.SysTable.Delete-fm', '', '/admin-api/v1/sys/tables/info/:tableId', '', 'DELETE', '2022-05-18 11:19:55.863', '2022-05-18 11:19:55.863', 0, 0);
INSERT INTO `sys_api` VALUES (116, 'go-admin/app/admin/apis.SysDept.Delete-fm', '', '/admin-api/v1/sys/dept/:id', '', 'DELETE', '2022-05-18 11:19:56.063', '2022-05-18 11:19:56.063', 0, 0);
INSERT INTO `sys_api` VALUES (117, 'go-admin/app/admin/apis.SysPost.Delete-fm', '', '/admin-api/v1/sys/post', '', 'DELETE', '2022-05-18 11:19:56.267', '2022-05-18 11:19:56.267', 0, 0);
INSERT INTO `sys_api` VALUES (118, 'go-admin/app/admin/apis.SysLoginLog.Delete-fm', '', '/admin-api/v1/sys-login-log', '', 'DELETE', '2022-05-18 11:19:56.483', '2022-05-18 11:19:56.483', 0, 0);
INSERT INTO `sys_api` VALUES (119, 'go-admin/app/admin/apis.SysOperaLog.Delete-fm', '', '/admin-api/v1/sys-opera-log', '', 'DELETE', '2022-05-18 11:19:56.683', '2022-05-18 11:19:56.683', 0, 0);
INSERT INTO `sys_api` VALUES (120, 'go-admin/app/admin/apis.SysUser.Delete-fm', '', '/admin-api/v1/sys-user', '', 'DELETE', '2022-05-18 11:19:56.882', '2022-05-18 11:19:56.882', 0, 0);
INSERT INTO `sys_api` VALUES (121, 'go-admin/app/plugins/content/apis.Announcement.Delete-fm', '', '/admin-api/v1/content/announcement', '', 'DELETE', '2022-05-18 11:19:57.087', '2022-05-18 11:19:57.087', 0, 0);
INSERT INTO `sys_api` VALUES (122, 'go-admin/app/plugins/content/apis.Article.Delete-fm', '', '/admin-api/v1/content/article', '', 'DELETE', '2022-05-18 11:19:57.295', '2022-05-18 11:19:57.295', 0, 0);
INSERT INTO `sys_api` VALUES (123, 'go-admin/app/plugins/content/apis.Category.Delete-fm', '', '/admin-api/v1/content/category', '', 'DELETE', '2022-05-18 11:19:57.488', '2022-05-18 11:19:57.488', 0, 0);
INSERT INTO `sys_api` VALUES (124, 'go-admin/app/admin/apis.SysConfig.Delete-fm', '', '/admin-api/v1/config', '', 'DELETE', '2022-05-18 11:19:57.691', '2022-05-18 11:19:57.691', 0, 0);
INSERT INTO `sys_api` VALUES (125, 'go-admin/app/admin/apis.SysDictData.Delete-fm', '', '/admin-api/v1/dict/data', '', 'DELETE', '2022-05-18 11:19:57.895', '2022-05-18 11:19:57.895', 0, 0);
INSERT INTO `sys_api` VALUES (126, 'go-admin/app/admin/apis.SysDictType.Delete-fm', '', '/admin-api/v1/dict/type', '', 'DELETE', '2022-05-18 11:19:58.099', '2022-05-18 11:19:58.099', 0, 0);
INSERT INTO `sys_api` VALUES (127, 'go-admin/app/admin/apis.SysMenu.Delete-fm', '', '/admin-api/v1/menu', '', 'DELETE', '2022-05-18 11:19:58.335', '2022-05-18 11:19:58.335', 0, 0);
INSERT INTO `sys_api` VALUES (128, 'go-admin/app/admin/apis.SysRole.Delete-fm', '', '/admin-api/v1/role', '', 'DELETE', '2022-05-18 11:19:58.535', '2022-05-18 11:19:58.535', 0, 0);
INSERT INTO `sys_api` VALUES (129, 'go-admin/app/plugins/filemgr/apis.App.Delete-fm', '', '/admin-api/v1/filemgr/app', '', 'DELETE', '2022-05-18 11:19:58.743', '2022-05-18 11:19:58.743', 0, 0);
COMMIT;

-- ----------------------------
-- Table structure for sys_casbin_rule
-- ----------------------------
DROP TABLE IF EXISTS `sys_casbin_rule`;
CREATE TABLE `sys_casbin_rule` (
  `p_type` varchar(100) DEFAULT NULL,
  `v0` varchar(100) DEFAULT NULL,
  `v1` varchar(100) DEFAULT NULL,
  `v2` varchar(100) DEFAULT NULL,
  `v3` varchar(100) DEFAULT NULL,
  `v4` varchar(100) DEFAULT NULL,
  `v5` varchar(100) DEFAULT NULL,
  UNIQUE KEY `idx_sys_casbin_rule` (`p_type`,`v0`,`v1`,`v2`,`v3`,`v4`,`v5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of sys_casbin_rule
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_columns
-- ----------------------------
DROP TABLE IF EXISTS `sys_columns`;
CREATE TABLE `sys_columns` (
  `column_id` bigint NOT NULL AUTO_INCREMENT,
  `table_id` bigint DEFAULT NULL,
  `column_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `column_comment` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `column_type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `go_type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `go_field` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `json_field` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_pk` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_increment` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_required` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_insert` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_edit` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_list` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_query` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `query_type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `html_type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `dict_type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sort` bigint DEFAULT NULL,
  `list` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `pk` tinyint(1) DEFAULT NULL,
  `required` tinyint(1) DEFAULT NULL,
  `super_column` tinyint(1) DEFAULT NULL,
  `usable_column` tinyint(1) DEFAULT NULL,
  `increment` tinyint(1) DEFAULT NULL,
  `insert` tinyint(1) DEFAULT NULL,
  `edit` tinyint(1) DEFAULT NULL,
  `query` tinyint(1) DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`column_id`),
  KEY `idx_sys_columns_create_by` (`create_by`),
  KEY `idx_sys_columns_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=780 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_columns
-- ----------------------------
BEGIN;
INSERT INTO `sys_columns` VALUES (79, 46, 'id', '主键编码', 'int(11)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-17 02:17:29.939', '2022-04-17 02:17:29.939', 0, 0);
INSERT INTO `sys_columns` VALUES (80, 46, 'name', '名称', 'varchar(255)', 'string', 'Name', 'name', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-17 02:17:29.941', '2022-04-18 13:40:47.698', 0, 0);
INSERT INTO `sys_columns` VALUES (81, 46, 'status', '状态', 'char(1)', 'string', 'Status', 'status', '0', '', '0', '0', '1', '0', '0', 'EQ', 'input', '', 3, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-17 02:17:30.026', '2022-04-18 13:40:47.901', 0, 0);
INSERT INTO `sys_columns` VALUES (82, 46, 'remark', '备注信息', 'varchar(500)', 'string', 'Remark', 'remark', '0', '', '0', '0', '1', '0', '0', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-17 02:17:30.032', '2022-04-18 13:40:48.096', 0, 0);
INSERT INTO `sys_columns` VALUES (83, 46, 'create_by', '创建者', 'int(11)', 'int64', 'CreateBy', 'createBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 5, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-17 02:17:30.035', '2022-04-17 02:17:30.035', 0, 0);
INSERT INTO `sys_columns` VALUES (84, 46, 'update_by', '更新者', 'int(11)', 'int64', 'UpdateBy', 'updateBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 6, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-17 02:17:30.037', '2022-04-17 02:17:30.037', 0, 0);
INSERT INTO `sys_columns` VALUES (85, 46, 'updated_at', '更新时间', 'datetime', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 7, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-17 02:17:30.039', '2022-04-17 02:17:30.039', 0, 0);
INSERT INTO `sys_columns` VALUES (86, 46, 'created_at', '创建时间', 'datetime', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 8, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-17 02:17:30.046', '2022-04-17 02:17:30.046', 0, 0);
INSERT INTO `sys_columns` VALUES (87, 47, 'id', '主键编码', 'bigint(20)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:51.787', '2022-04-18 17:19:51.787', 0, 0);
INSERT INTO `sys_columns` VALUES (88, 47, 'cate_id', '分类编号', 'bigint(20)', 'int64', 'CateId', 'cateId', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:51.974', '2022-04-18 17:23:21.049', 0, 0);
INSERT INTO `sys_columns` VALUES (89, 47, 'name', '名称', 'varchar(255)', 'string', 'Name', 'name', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:52.139', '2022-04-18 17:23:21.241', 0, 0);
INSERT INTO `sys_columns` VALUES (90, 47, 'content', '内容', 'text', 'string', 'Content', 'content', '0', '', '1', '1', '1', '1', '0', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:52.326', '2022-04-18 17:23:21.450', 0, 0);
INSERT INTO `sys_columns` VALUES (91, 47, 'remark', '备注信息', 'varchar(500)', 'string', 'Remark', 'remark', '0', '', '1', '1', '1', '1', '0', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:52.514', '2022-04-18 17:23:21.644', 0, 0);
INSERT INTO `sys_columns` VALUES (92, 47, 'status', '状态', 'char(1)', 'string', 'Status', 'status', '0', '', '1', '1', '1', '1', '0', 'EQ', 'select', 'sys_status', 6, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:52.702', '2022-04-18 17:23:21.913', 0, 0);
INSERT INTO `sys_columns` VALUES (93, 47, 'create_by', '创建者', 'int(11)', 'int64', 'CreateBy', 'createBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 7, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:52.885', '2022-04-18 17:19:52.885', 0, 0);
INSERT INTO `sys_columns` VALUES (94, 47, 'update_by', '更新者', 'int(11)', 'int64', 'UpdateBy', 'updateBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 8, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:53.046', '2022-04-18 17:19:53.046', 0, 0);
INSERT INTO `sys_columns` VALUES (95, 47, 'updated_at', '更新时间', 'datetime', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 9, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:53.230', '2022-04-18 17:19:53.230', 0, 0);
INSERT INTO `sys_columns` VALUES (96, 47, 'created_at', '创建时间', 'datetime', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 10, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-18 17:19:53.383', '2022-04-18 17:19:53.383', 0, 0);
INSERT INTO `sys_columns` VALUES (97, 48, 'id', '主键编码', 'bigint(20)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:33.272', '2022-04-19 17:19:33.272', 0, 0);
INSERT INTO `sys_columns` VALUES (98, 48, 'title', '标题', 'varchar(255)', 'string', 'Title', 'title', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:34.701', '2022-04-19 17:30:38.986', 0, 0);
INSERT INTO `sys_columns` VALUES (99, 48, 'content', '内容', 'text', 'string', 'Content', 'content', '0', '', '1', '1', '1', '1', '0', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:35.570', '2022-04-19 17:30:39.187', 0, 0);
INSERT INTO `sys_columns` VALUES (100, 48, 'num', '阅读次数', 'int(11)', 'int64', 'Num', 'num', '0', '', '1', '1', '1', '1', '0', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:35.740', '2022-04-19 17:30:39.419', 0, 0);
INSERT INTO `sys_columns` VALUES (101, 48, 'remark', '备注信息', 'varchar(500)', 'string', 'Remark', 'remark', '0', '', '1', '1', '1', '1', '0', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:35.907', '2022-04-19 17:30:39.622', 0, 0);
INSERT INTO `sys_columns` VALUES (102, 48, 'status', '状态', 'char(1)', 'string', 'Status', 'status', '0', '', '1', '1', '1', '1', '1', 'EQ', 'select', 'sys_status', 6, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:36.070', '2022-04-19 17:30:39.931', 0, 0);
INSERT INTO `sys_columns` VALUES (103, 48, 'create_by', '创建者', 'int(11)', 'int64', 'CreateBy', 'createBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 7, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:36.230', '2022-04-19 17:19:36.230', 0, 0);
INSERT INTO `sys_columns` VALUES (104, 48, 'update_by', '更新者', 'int(11)', 'int64', 'UpdateBy', 'updateBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 8, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:36.390', '2022-04-19 17:19:36.390', 0, 0);
INSERT INTO `sys_columns` VALUES (105, 48, 'updated_at', '更新时间', 'datetime', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 9, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:36.550', '2022-04-19 17:19:36.550', 0, 0);
INSERT INTO `sys_columns` VALUES (106, 48, 'created_at', '创建时间', 'datetime', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 10, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 17:19:36.771', '2022-04-19 17:19:36.771', 0, 0);
INSERT INTO `sys_columns` VALUES (107, 49, 'id', '主键', 'int(11)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.240', '2022-04-19 20:58:51.240', 0, 0);
INSERT INTO `sys_columns` VALUES (108, 49, 'version', '版本号', 'varchar(100)', 'string', 'Version', 'version', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.245', '2022-04-19 22:20:01.677', 0, 0);
INSERT INTO `sys_columns` VALUES (109, 49, 'platform', '平台 ( 0:安卓 1:苹果 )', 'char(1)', 'string', 'Platform', 'platform', '0', '', '0', '1', '1', '1', '1', 'EQ', 'select', 'app_platform', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.247', '2022-04-19 22:20:01.681', 0, 0);
INSERT INTO `sys_columns` VALUES (110, 49, 'type', '版本(0:中文版 1:英文版  2:运营商版)', 'varchar(255)', 'string', 'Type', 'type', '0', '', '0', '1', '1', '1', '1', 'EQ', 'select', 'app_type', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.249', '2022-04-19 22:20:01.685', 0, 0);
INSERT INTO `sys_columns` VALUES (111, 49, 'local_address', '本地地址', 'varchar(255)', 'string', 'LocalAddress', 'localAddress', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.252', '2022-04-19 22:20:01.688', 0, 0);
INSERT INTO `sys_columns` VALUES (112, 49, 'bucket_name', 'bucketName，用于生成下载链接', 'varchar(255)', 'string', 'BucketName', 'bucketName', '0', '', '0', '1', '1', '0', '0', 'EQ', 'input', '', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.257', '2022-04-19 22:20:01.691', 0, 0);
INSERT INTO `sys_columns` VALUES (113, 49, 'oss_key', '用于生成下载链接', 'varchar(255)', 'string', 'OssKey', 'ossKey', '0', '', '0', '1', '1', '0', '0', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.259', '2022-04-19 22:20:01.694', 0, 0);
INSERT INTO `sys_columns` VALUES (114, 49, 'download_num', '下载数量', 'decimal(10,0)', 'decimal.Decimal', 'DownloadNum', 'downloadNum', '0', '', '0', '1', '1', '0', '0', 'EQ', 'input', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.262', '2022-04-19 22:20:01.720', 0, 0);
INSERT INTO `sys_columns` VALUES (115, 49, 'download_type', '下载类型(0-oss 1-外链)', 'char(1)', 'string', 'DownloadType', 'downloadType', '0', '', '0', '1', '1', '1', '1', 'EQ', 'select', 'app_download_type', 9, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.264', '2022-04-19 22:20:01.723', 0, 0);
INSERT INTO `sys_columns` VALUES (116, 49, 'download_url', '下载地址(download_type=1使用)', 'varchar(255)', 'string', 'DownloadUrl', 'downloadUrl', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 10, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.266', '2022-04-19 22:20:01.727', 0, 0);
INSERT INTO `sys_columns` VALUES (117, 49, 'remark', '备注信息', 'varchar(500)', 'string', 'Remark', 'remark', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 11, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.268', '2022-04-19 22:20:01.730', 0, 0);
INSERT INTO `sys_columns` VALUES (118, 49, 'status', '状态（0正常 1删除 2停用 3冻结）', 'char(1)', 'string', 'Status', 'status', '0', '', '1', '1', '1', '1', '1', 'EQ', 'select', 'app_status', 12, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.270', '2022-04-19 22:20:01.733', 0, 0);
INSERT INTO `sys_columns` VALUES (119, 49, 'create_by', '创建者', 'int(11)', 'int64', 'CreateBy', 'createBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 13, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.273', '2022-04-19 20:58:51.273', 0, 0);
INSERT INTO `sys_columns` VALUES (120, 49, 'update_by', '更新者', 'int(11)', 'int64', 'UpdateBy', 'updateBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 14, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.275', '2022-04-19 20:58:51.275', 0, 0);
INSERT INTO `sys_columns` VALUES (121, 49, 'updated_at', '更新时间', 'datetime', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 15, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.277', '2022-04-19 20:58:51.277', 0, 0);
INSERT INTO `sys_columns` VALUES (122, 49, 'created_at', '创建时间', 'datetime', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 16, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-19 20:58:51.279', '2022-04-19 20:58:51.279', 0, 0);
INSERT INTO `sys_columns` VALUES (123, 50, 'id', '主键编码', 'bigint(20)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.911', '2022-04-24 17:16:00.911', 0, 0);
INSERT INTO `sys_columns` VALUES (124, 50, 'handle', 'handle', 'varchar(128)', 'string', 'Handle', 'handle', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.916', '2022-04-26 00:11:05.080', 0, 0);
INSERT INTO `sys_columns` VALUES (125, 50, 'title', '标题', 'varchar(128)', 'string', 'Title', 'title', '0', '', '0', '1', '1', '1', '1', 'LIKE', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.918', '2022-04-26 00:11:05.237', 0, 0);
INSERT INTO `sys_columns` VALUES (126, 50, 'path', '地址', 'varchar(128)', 'string', 'Path', 'path', '0', '', '0', '0', '1', '1', '1', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.921', '2022-04-26 00:11:05.401', 0, 0);
INSERT INTO `sys_columns` VALUES (127, 50, 'type', '接口类型', 'varchar(16)', 'string', 'Type', 'type', '0', '', '0', '1', '1', '1', '1', 'EQ', 'select', 'sys_api_type', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.923', '2022-04-26 00:11:05.562', 0, 0);
INSERT INTO `sys_columns` VALUES (128, 50, 'action', '请求类型', 'varchar(16)', 'string', 'Action', 'action', '0', '', '0', '1', '1', '1', '1', 'EQ', 'select', 'sys_request_type', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.926', '2022-04-26 00:11:05.716', 0, 0);
INSERT INTO `sys_columns` VALUES (129, 50, 'created_at', '创建时间', 'datetime(3)', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.928', '2022-04-24 17:16:00.928', 0, 0);
INSERT INTO `sys_columns` VALUES (130, 50, 'updated_at', '最后更新时间', 'datetime(3)', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.934', '2022-04-24 17:16:00.934', 0, 0);
INSERT INTO `sys_columns` VALUES (132, 50, 'create_by', '创建者', 'bigint(20)', 'int64', 'CreateBy', 'createBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 10, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.939', '2022-04-24 17:16:00.939', 0, 0);
INSERT INTO `sys_columns` VALUES (133, 50, 'update_by', '更新者', 'bigint(20)', 'int64', 'UpdateBy', 'updateBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 11, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 17:16:00.941', '2022-04-24 17:16:00.941', 0, 0);
INSERT INTO `sys_columns` VALUES (134, 51, 'dict_id', '字典编号', 'bigint(20)', 'int64', 'DictId', 'dictId', '1', '', '0', '0', '1', '1', '0', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-24 20:10:02.253', '2022-04-24 20:39:17.789', 0, 0);
INSERT INTO `sys_columns` VALUES (135, 51, 'dict_name', '字典名称', 'varchar(128)', 'string', 'DictName', 'dictName', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 20:10:02.256', '2022-04-24 20:39:17.791', 0, 0);
INSERT INTO `sys_columns` VALUES (136, 51, 'dict_type', '字典类型', 'varchar(128)', 'string', 'DictType', 'dictType', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 20:10:02.276', '2022-04-24 20:39:17.794', 0, 0);
INSERT INTO `sys_columns` VALUES (137, 51, 'status', '状态', 'tinyint(4)', 'int64', 'Status', 'status', '0', '', '1', '1', '1', '1', '1', 'EQ', 'select', 'sys_status', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 20:10:02.279', '2022-04-24 20:39:17.797', 0, 0);
INSERT INTO `sys_columns` VALUES (138, 51, 'remark', '备注', 'varchar(255)', 'string', 'Remark', 'remark', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 20:10:02.281', '2022-04-24 20:39:17.800', 0, 0);
INSERT INTO `sys_columns` VALUES (139, 51, 'create_by', '创建者', 'bigint(20)', 'int64', 'CreateBy', 'createBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 20:10:02.283', '2022-04-24 20:10:02.283', 0, 0);
INSERT INTO `sys_columns` VALUES (140, 51, 'update_by', '更新者', 'bigint(20)', 'int64', 'UpdateBy', 'updateBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 20:10:02.285', '2022-04-24 20:10:02.285', 0, 0);
INSERT INTO `sys_columns` VALUES (141, 51, 'created_at', '创建时间', 'datetime(3)', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 20:10:02.287', '2022-04-24 20:10:02.287', 0, 0);
INSERT INTO `sys_columns` VALUES (142, 51, 'updated_at', '最后更新时间', 'datetime(3)', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 9, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 20:10:02.291', '2022-04-24 20:10:02.291', 0, 0);
INSERT INTO `sys_columns` VALUES (144, 52, 'dict_code', '字典编码', 'bigint(20)', 'int64', 'DictCode', 'dictCode', '1', '', '0', '0', '1', '1', '0', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:28.875', '2022-04-24 21:45:31.521', 0, 0);
INSERT INTO `sys_columns` VALUES (145, 52, 'dict_sort', '字典排序', 'bigint(20)', 'int64', 'DictSort', 'dictSort', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:29.005', '2022-04-24 21:45:31.694', 0, 0);
INSERT INTO `sys_columns` VALUES (146, 52, 'dict_label', '字典标签', 'varchar(128)', 'string', 'DictLabel', 'dictLabel', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:29.145', '2022-04-24 21:45:31.878', 0, 0);
INSERT INTO `sys_columns` VALUES (147, 52, 'dict_value', '字典键值', 'varchar(255)', 'string', 'DictValue', 'dictValue', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:29.264', '2022-04-24 21:45:32.053', 0, 0);
INSERT INTO `sys_columns` VALUES (148, 52, 'dict_type', '字典类型', 'varchar(64)', 'string', 'DictType', 'dictType', '0', '', '0', '1', '1', '0', '0', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:29.384', '2022-04-24 21:45:32.228', 0, 0);
INSERT INTO `sys_columns` VALUES (149, 52, 'css_class', '', 'varchar(128)', 'string', 'CssClass', 'cssClass', '0', '', '0', '0', '1', '0', '0', 'EQ', 'input', '', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:29.507', '2022-04-24 21:45:32.400', 0, 0);
INSERT INTO `sys_columns` VALUES (150, 52, 'list_class', '', 'varchar(128)', 'string', 'ListClass', 'listClass', '0', '', '0', '0', '1', '0', '0', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:29.627', '2022-04-24 21:45:32.578', 0, 0);
INSERT INTO `sys_columns` VALUES (151, 52, 'is_default', '', 'varchar(8)', 'string', 'IsDefault', 'isDefault', '0', '', '0', '0', '1', '0', '0', 'EQ', 'input', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:29.746', '2022-04-24 21:45:32.749', 0, 0);
INSERT INTO `sys_columns` VALUES (152, 52, 'status', '', 'char(1)', 'string', 'Status', 'status', '0', '', '0', '1', '1', '1', '1', 'EQ', 'radio', 'sys_status', 9, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:29.872', '2022-04-24 21:45:32.921', 0, 0);
INSERT INTO `sys_columns` VALUES (153, 52, 'default', '', 'varchar(8)', 'string', 'Default', 'default', '0', '', '0', '0', '1', '0', '0', 'EQ', 'input', '', 10, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:29.991', '2022-04-24 21:45:33.132', 0, 0);
INSERT INTO `sys_columns` VALUES (154, 52, 'remark', '', 'varchar(255)', 'string', 'Remark', 'remark', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 11, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:30.113', '2022-04-24 21:45:33.305', 0, 0);
INSERT INTO `sys_columns` VALUES (155, 52, 'create_by', '创建者', 'bigint(20)', 'int64', 'CreateBy', 'createBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 12, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:30.231', '2022-04-24 21:39:30.231', 0, 0);
INSERT INTO `sys_columns` VALUES (156, 52, 'update_by', '更新者', 'bigint(20)', 'int64', 'UpdateBy', 'updateBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 13, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:30.354', '2022-04-24 21:39:30.354', 0, 0);
INSERT INTO `sys_columns` VALUES (157, 52, 'created_at', '创建时间', 'datetime(3)', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 14, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:30.481', '2022-04-24 21:39:30.481', 0, 0);
INSERT INTO `sys_columns` VALUES (158, 52, 'updated_at', '最后更新时间', 'datetime(3)', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 15, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:30.601', '2022-04-24 21:39:30.601', 0, 0);
INSERT INTO `sys_columns` VALUES (159, 52, 'deleted_at', '删除时间', 'datetime(3)', '*time.Time', 'DeletedAt', 'deletedAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 16, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-24 21:39:30.728', '2022-04-24 21:39:30.728', 0, 0);
INSERT INTO `sys_columns` VALUES (160, 53, 'id', '主键编码', 'bigint(20)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:38.669', '2022-04-25 09:47:38.669', 0, 0);
INSERT INTO `sys_columns` VALUES (161, 53, 'config_name', '配置名称', 'varchar(128)', 'string', 'ConfigName', 'configName', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:38.813', '2022-04-25 10:06:50.044', 0, 0);
INSERT INTO `sys_columns` VALUES (162, 53, 'config_key', '配置键名', 'varchar(128)', 'string', 'ConfigKey', 'configKey', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:38.969', '2022-04-25 10:06:50.284', 0, 0);
INSERT INTO `sys_columns` VALUES (163, 53, 'config_value', '配置键值', 'varchar(255)', 'string', 'ConfigValue', 'configValue', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:39.118', '2022-04-25 10:06:50.486', 0, 0);
INSERT INTO `sys_columns` VALUES (164, 53, 'config_type', '配置类型', 'varchar(64)', 'string', 'ConfigType', 'configType', '0', '', '0', '1', '1', '1', '1', 'EQ', 'select', 'sys_yes_no', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:39.269', '2022-04-25 10:06:50.676', 0, 0);
INSERT INTO `sys_columns` VALUES (165, 53, 'is_frontend', '是否前台', 'varchar(64)', 'string', 'IsFrontend', 'isFrontend', '0', '', '0', '1', '1', '1', '1', 'EQ', 'select', 'sys_yes_no', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:39.421', '2022-04-25 10:06:50.868', 0, 0);
INSERT INTO `sys_columns` VALUES (166, 53, 'remark', '备注', 'varchar(128)', 'string', 'Remark', 'remark', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:39.569', '2022-04-25 10:06:51.059', 0, 0);
INSERT INTO `sys_columns` VALUES (167, 53, 'create_by', '创建者', 'bigint(20)', 'int64', 'CreateBy', 'createBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:39.717', '2022-04-25 09:47:39.717', 0, 0);
INSERT INTO `sys_columns` VALUES (168, 53, 'update_by', '更新者', 'bigint(20)', 'int64', 'UpdateBy', 'updateBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 9, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:39.869', '2022-04-25 09:47:39.869', 0, 0);
INSERT INTO `sys_columns` VALUES (169, 53, 'created_at', '创建时间', 'datetime(3)', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 10, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:40.025', '2022-04-25 09:47:40.025', 0, 0);
INSERT INTO `sys_columns` VALUES (170, 53, 'updated_at', '最后更新时间', 'datetime(3)', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 11, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 09:47:40.177', '2022-04-25 09:47:40.177', 0, 0);
INSERT INTO `sys_columns` VALUES (172, 54, 'id', '主键编码', 'bigint(20)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:10.713', '2022-04-25 14:38:10.713', 0, 0);
INSERT INTO `sys_columns` VALUES (173, 54, 'username', '用户名', 'varchar(128)', 'string', 'Username', 'username', '0', '', '0', '0', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:10.865', '2022-04-25 14:48:45.536', 0, 0);
INSERT INTO `sys_columns` VALUES (174, 54, 'status', '状态', 'varchar(4)', 'string', 'Status', 'status', '0', '', '0', '0', '1', '1', '1', 'EQ', 'select', 'sys_status', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:11.030', '2022-04-25 14:48:45.735', 0, 0);
INSERT INTO `sys_columns` VALUES (175, 54, 'ipaddr', 'ip地址', 'varchar(255)', 'string', 'Ipaddr', 'ipaddr', '0', '', '0', '0', '1', '1', '1', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:11.205', '2022-04-25 14:48:45.936', 0, 0);
INSERT INTO `sys_columns` VALUES (176, 54, 'login_location', '归属地', 'varchar(255)', 'string', 'LoginLocation', 'loginLocation', '0', '', '0', '0', '1', '1', '0', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:11.385', '2022-04-25 14:48:46.128', 0, 0);
INSERT INTO `sys_columns` VALUES (177, 54, 'browser', '浏览器', 'varchar(255)', 'string', 'Browser', 'browser', '0', '', '0', '0', '1', '1', '0', 'EQ', 'input', '', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:11.533', '2022-04-25 14:48:46.332', 0, 0);
INSERT INTO `sys_columns` VALUES (178, 54, 'os', '系统', 'varchar(255)', 'string', 'Os', 'os', '0', '', '0', '0', '1', '1', '0', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:11.689', '2022-04-25 14:48:46.537', 0, 0);
INSERT INTO `sys_columns` VALUES (179, 54, 'platform', '固件', 'varchar(255)', 'string', 'Platform', 'platform', '0', '', '0', '0', '1', '1', '0', 'EQ', 'input', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:11.864', '2022-04-25 14:48:46.732', 0, 0);
INSERT INTO `sys_columns` VALUES (180, 54, 'login_time', '登录时间', 'timestamp', '*time.Time', 'LoginTime', 'loginTime', '0', '', '1', '0', '1', '1', '0', 'EQ', 'datetime', '', 9, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:11.997', '2022-04-25 14:48:46.924', 0, 0);
INSERT INTO `sys_columns` VALUES (181, 54, 'remark', '备注', 'varchar(255)', 'string', 'Remark', 'remark', '0', '', '0', '0', '1', '1', '0', 'EQ', 'input', '', 10, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:12.153', '2022-04-25 14:48:47.120', 0, 0);
INSERT INTO `sys_columns` VALUES (182, 54, 'msg', '信息', 'varchar(255)', 'string', 'Msg', 'msg', '0', '', '0', '0', '1', '1', '0', 'EQ', 'input', '', 11, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:12.309', '2022-04-25 14:48:47.388', 0, 0);
INSERT INTO `sys_columns` VALUES (183, 54, 'created_at', '创建时间', 'datetime(3)', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 12, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:12.445', '2022-04-25 14:38:12.445', 0, 0);
INSERT INTO `sys_columns` VALUES (184, 54, 'updated_at', '最后更新时间', 'datetime(3)', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 13, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:12.605', '2022-04-25 14:38:12.605', 0, 0);
INSERT INTO `sys_columns` VALUES (185, 54, 'create_by', '创建者', 'bigint(20)', 'int64', 'CreateBy', 'createBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 14, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:12.737', '2022-04-25 14:38:12.737', 0, 0);
INSERT INTO `sys_columns` VALUES (186, 54, 'update_by', '更新者', 'bigint(20)', 'int64', 'UpdateBy', 'updateBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 15, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 14:38:12.897', '2022-04-25 14:38:12.897', 0, 0);
INSERT INTO `sys_columns` VALUES (187, 55, 'id', '主键编码', 'bigint(20)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:26.627', '2022-04-25 15:27:26.627', 0, 0);
INSERT INTO `sys_columns` VALUES (188, 55, 'title', '操作模块', 'varchar(255)', 'string', 'Title', 'title', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:26.840', '2022-04-25 15:33:14.096', 0, 0);
INSERT INTO `sys_columns` VALUES (189, 55, 'business_type', '操作类型', 'varchar(128)', 'string', 'BusinessType', 'businessType', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:27.015', '2022-04-25 15:33:14.375', 0, 0);
INSERT INTO `sys_columns` VALUES (190, 55, 'business_types', 'BusinessTypes', 'varchar(128)', 'string', 'BusinessTypes', 'businessTypes', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:27.233', '2022-04-25 15:33:14.995', 0, 0);
INSERT INTO `sys_columns` VALUES (191, 55, 'method', '函数', 'varchar(128)', 'string', 'Method', 'method', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:27.411', '2022-04-25 15:33:15.274', 0, 0);
INSERT INTO `sys_columns` VALUES (192, 55, 'request_method', '请求方式', 'varchar(128)', 'string', 'RequestMethod', 'requestMethod', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:27.623', '2022-04-25 15:33:15.575', 0, 0);
INSERT INTO `sys_columns` VALUES (193, 55, 'operator_type', '操作类型', 'varchar(128)', 'string', 'OperatorType', 'operatorType', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:27.799', '2022-04-25 15:33:15.871', 0, 0);
INSERT INTO `sys_columns` VALUES (194, 55, 'oper_name', '操作者', 'varchar(128)', 'string', 'OperName', 'operName', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:28.010', '2022-04-25 15:33:16.146', 0, 0);
INSERT INTO `sys_columns` VALUES (195, 55, 'dept_name', '部门名称', 'varchar(128)', 'string', 'DeptName', 'deptName', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 9, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:28.187', '2022-04-25 15:33:16.423', 0, 0);
INSERT INTO `sys_columns` VALUES (196, 55, 'oper_url', '访问地址', 'varchar(255)', 'string', 'OperUrl', 'operUrl', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 10, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:28.411', '2022-04-25 15:33:16.698', 0, 0);
INSERT INTO `sys_columns` VALUES (197, 55, 'oper_ip', '客户端ip', 'varchar(128)', 'string', 'OperIp', 'operIp', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 11, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:28.587', '2022-04-25 15:33:17.027', 0, 0);
INSERT INTO `sys_columns` VALUES (198, 55, 'oper_location', '访问位置', 'varchar(128)', 'string', 'OperLocation', 'operLocation', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 12, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:28.803', '2022-04-25 15:33:17.328', 0, 0);
INSERT INTO `sys_columns` VALUES (199, 55, 'oper_param', '请求参数', 'varchar(255)', 'string', 'OperParam', 'operParam', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 13, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:28.975', '2022-04-25 15:33:17.618', 0, 0);
INSERT INTO `sys_columns` VALUES (200, 55, 'status', '操作状态', 'varchar(4)', 'string', 'Status', 'status', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 14, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:29.187', '2022-04-25 15:33:17.896', 0, 0);
INSERT INTO `sys_columns` VALUES (201, 55, 'oper_time', '操作时间', 'timestamp', '*time.Time', 'OperTime', 'operTime', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 15, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:29.371', '2022-04-25 15:33:18.187', 0, 0);
INSERT INTO `sys_columns` VALUES (202, 55, 'json_result', '返回数据', 'varchar(255)', 'string', 'JsonResult', 'jsonResult', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 16, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:29.587', '2022-04-25 15:33:18.467', 0, 0);
INSERT INTO `sys_columns` VALUES (203, 55, 'remark', '备注', 'varchar(255)', 'string', 'Remark', 'remark', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 17, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:29.771', '2022-04-25 15:33:18.743', 0, 0);
INSERT INTO `sys_columns` VALUES (204, 55, 'latency_time', '耗时', 'varchar(128)', 'string', 'LatencyTime', 'latencyTime', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 18, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:29.985', '2022-04-25 15:33:19.011', 0, 0);
INSERT INTO `sys_columns` VALUES (205, 55, 'user_agent', 'ua', 'varchar(255)', 'string', 'UserAgent', 'userAgent', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 19, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:30.163', '2022-04-25 15:33:19.290', 0, 0);
INSERT INTO `sys_columns` VALUES (206, 55, 'created_at', '创建时间', 'datetime(3)', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 20, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:30.379', '2022-04-25 15:27:30.379', 0, 0);
INSERT INTO `sys_columns` VALUES (207, 55, 'updated_at', '最后更新时间', 'datetime(3)', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 21, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:30.556', '2022-04-25 15:27:30.556', 0, 0);
INSERT INTO `sys_columns` VALUES (208, 55, 'create_by', '创建者', 'bigint(20)', 'int64', 'CreateBy', 'createBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 22, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:30.767', '2022-04-25 15:27:30.767', 0, 0);
INSERT INTO `sys_columns` VALUES (209, 55, 'update_by', '更新者', 'bigint(20)', 'int64', 'UpdateBy', 'updateBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 23, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-25 15:27:30.950', '2022-04-25 15:27:30.950', 0, 0);
INSERT INTO `sys_columns` VALUES (210, 56, 'post_id', '岗位编号', 'int(11)', 'int64', 'PostId', 'postId', '1', '', '0', '0', '1', '0', '0', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:50.117', '2022-04-26 13:34:02.244', 0, 0);
INSERT INTO `sys_columns` VALUES (211, 56, 'post_name', '岗位名称', 'varchar(128)', 'string', 'PostName', 'postName', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:50.277', '2022-04-26 13:34:02.435', 0, 0);
INSERT INTO `sys_columns` VALUES (212, 56, 'post_code', '岗位编码', 'varchar(128)', 'string', 'PostCode', 'postCode', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:50.429', '2022-04-26 13:34:02.652', 0, 0);
INSERT INTO `sys_columns` VALUES (213, 56, 'sort', '排序', 'tinyint(4)', 'int64', 'Sort', 'sort', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:50.581', '2022-04-26 13:34:02.849', 0, 0);
INSERT INTO `sys_columns` VALUES (214, 56, 'status', '状态', 'char(1)', 'string', 'Status', 'status', '0', '', '0', '1', '1', '1', '1', 'EQ', 'select', 'sys_status', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:50.737', '2022-04-26 13:34:03.052', 0, 0);
INSERT INTO `sys_columns` VALUES (215, 56, 'remark', '备注', 'varchar(255)', 'string', 'Remark', 'remark', '0', '', '0', '1', '1', '1', '0', 'EQ', 'input', '', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:50.889', '2022-04-26 13:34:03.249', 0, 0);
INSERT INTO `sys_columns` VALUES (216, 56, 'create_by', '创建者', 'bigint(20)', 'int64', 'CreateBy', 'createBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:51.049', '2022-04-26 12:50:51.049', 0, 0);
INSERT INTO `sys_columns` VALUES (217, 56, 'update_by', '更新者', 'bigint(20)', 'int64', 'UpdateBy', 'updateBy', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:51.201', '2022-04-26 12:50:51.201', 0, 0);
INSERT INTO `sys_columns` VALUES (218, 56, 'created_at', '创建时间', 'datetime(3)', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 9, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:51.353', '2022-04-26 12:50:51.353', 0, 0);
INSERT INTO `sys_columns` VALUES (219, 56, 'updated_at', '最后更新时间', 'datetime(3)', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 10, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-26 12:50:51.509', '2022-04-26 12:50:51.509', 0, 0);
INSERT INTO `sys_columns` VALUES (220, 57, 'id', '主键编码', 'int(11)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:17.789', '2022-04-28 21:26:17.789', 0, 0);
INSERT INTO `sys_columns` VALUES (221, 57, 'name', '名称', 'varchar(128)', 'string', 'Name', 'name', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:17.886', '2022-04-28 21:26:17.886', 0, 0);
INSERT INTO `sys_columns` VALUES (222, 57, 'pid', '质押池编号', 'int(11)', 'int64', 'Pid', 'pid', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:17.993', '2022-04-28 21:26:17.993', 0, 0);
INSERT INTO `sys_columns` VALUES (223, 57, 'address', '矿工地址', 'varchar(128)', 'string', 'Address', 'address', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:18.093', '2022-04-28 21:26:18.093', 0, 0);
INSERT INTO `sys_columns` VALUES (224, 57, 'public_key', '矿工公钥', 'varchar(128)', 'string', 'PublicKey', 'publicKey', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:18.189', '2022-04-28 21:26:18.189', 0, 0);
INSERT INTO `sys_columns` VALUES (225, 57, 'status', '状态（0正常 1删除 2停用 3冻结）', 'char(1)', 'string', 'Status', 'status', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 6, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:18.287', '2022-04-28 21:26:18.287', 0, 0);
INSERT INTO `sys_columns` VALUES (226, 57, 'remkark', '备注', 'varchar(500)', 'string', 'Remkark', 'remkark', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:18.388', '2022-04-28 21:26:18.388', 0, 0);
INSERT INTO `sys_columns` VALUES (227, 57, 'create_by', '创建者', 'int(11)', 'int64', 'CreateBy', 'createBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 8, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:18.484', '2022-04-28 21:26:18.484', 0, 0);
INSERT INTO `sys_columns` VALUES (228, 57, 'update_by', '更新者', 'int(11)', 'int64', 'UpdateBy', 'updateBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 9, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:18.583', '2022-04-28 21:26:18.583', 0, 0);
INSERT INTO `sys_columns` VALUES (229, 57, 'updated_at', '更新时间', 'datetime', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 10, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:18.680', '2022-04-28 21:26:18.680', 0, 0);
INSERT INTO `sys_columns` VALUES (230, 57, 'created_at', '创建时间', 'datetime', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 11, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:18.776', '2022-04-28 21:26:18.776', 0, 0);
INSERT INTO `sys_columns` VALUES (231, 58, 'id', '主键编码', 'int(11)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.097', '2022-04-28 21:26:19.097', 0, 0);
INSERT INTO `sys_columns` VALUES (232, 58, 'worker_id', 'worker公钥', 'int(11)', 'int64', 'WorkerId', 'workerId', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.193', '2022-04-28 21:26:19.193', 0, 0);
INSERT INTO `sys_columns` VALUES (233, 58, 'pid', '质押池编号', 'int(11)', 'int64', 'Pid', 'pid', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.293', '2022-04-28 21:26:19.293', 0, 0);
INSERT INTO `sys_columns` VALUES (234, 58, 'state', '计算状态', 'varchar(64)', 'string', 'State', 'state', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.393', '2022-04-28 21:26:19.393', 0, 0);
INSERT INTO `sys_columns` VALUES (235, 58, 've', '经济参数', 'decimal(30,18)', 'decimal.Decimal', 'Ve', 've', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.489', '2022-04-28 21:26:19.489', 0, 0);
INSERT INTO `sys_columns` VALUES (236, 58, 'v', '经济参数', 'decimal(30,18)', 'decimal.Decimal', 'V', 'v', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.585', '2022-04-28 21:26:19.585', 0, 0);
INSERT INTO `sys_columns` VALUES (237, 58, 'p_instant', 'p_instant', 'int(11)', 'int64', 'PInstant', 'pInstant', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.680', '2022-04-28 21:26:19.680', 0, 0);
INSERT INTO `sys_columns` VALUES (238, 58, 'p_initial', 'p_initial', 'int(11)', 'int64', 'PInitial', 'pInitial', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.776', '2022-04-28 21:26:19.776', 0, 0);
INSERT INTO `sys_columns` VALUES (239, 58, 'iterations', '迭代器', 'int(11)', 'int64', 'Iterations', 'iterations', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 9, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.871', '2022-04-28 21:26:19.871', 0, 0);
INSERT INTO `sys_columns` VALUES (240, 58, 'mining_start_time', '开挖时间', 'int(11)', 'int64', 'MiningStartTime', 'miningStartTime', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 10, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:19.967', '2022-04-28 21:26:19.967', 0, 0);
INSERT INTO `sys_columns` VALUES (241, 58, 'challenge_time_last', '最近挑战时间', 'int(11)', 'int64', 'ChallengeTimeLast', 'challengeTimeLast', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 11, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.067', '2022-04-28 21:26:20.067', 0, 0);
INSERT INTO `sys_columns` VALUES (242, 58, 'v_updated_at', 'v更新时间', 'int(11)', 'int64', 'VUpdatedAt', 'vUpdatedAt', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 12, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.164', '2022-04-28 21:26:20.164', 0, 0);
INSERT INTO `sys_columns` VALUES (243, 58, 'total_reward', '总共挖出', 'decimal(30,18)', 'decimal.Decimal', 'TotalReward', 'totalReward', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 13, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.262', '2022-04-28 21:26:20.262', 0, 0);
INSERT INTO `sys_columns` VALUES (244, 58, 'stake', '有效总质押', 'decimal(30,18)', 'decimal.Decimal', 'Stake', 'stake', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 14, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.358', '2022-04-28 21:26:20.358', 0, 0);
INSERT INTO `sys_columns` VALUES (245, 58, 'status', '状态（0正常 1删除 2停用 3冻结）', 'char(1)', 'string', 'Status', 'status', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 15, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.456', '2022-04-28 21:26:20.456', 0, 0);
INSERT INTO `sys_columns` VALUES (246, 58, 'remkark', '备注', 'varchar(500)', 'string', 'Remkark', 'remkark', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 16, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.556', '2022-04-28 21:26:20.556', 0, 0);
INSERT INTO `sys_columns` VALUES (247, 58, 'create_by', '创建者', 'int(11)', 'int64', 'CreateBy', 'createBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 17, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.654', '2022-04-28 21:26:20.654', 0, 0);
INSERT INTO `sys_columns` VALUES (248, 58, 'update_by', '更新者', 'int(11)', 'int64', 'UpdateBy', 'updateBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 18, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.755', '2022-04-28 21:26:20.755', 0, 0);
INSERT INTO `sys_columns` VALUES (249, 58, 'updated_at', '更新时间', 'datetime', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 19, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.854', '2022-04-28 21:26:20.854', 0, 0);
INSERT INTO `sys_columns` VALUES (250, 58, 'created_at', '创建时间', 'datetime', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 20, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:20.982', '2022-04-28 21:26:20.982', 0, 0);
INSERT INTO `sys_columns` VALUES (251, 59, 'id', '主键编码', 'bigint(20)', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:21.274', '2022-04-28 21:26:21.274', 0, 0);
INSERT INTO `sys_columns` VALUES (252, 59, 'pid', '质押池编号', 'int(11)', 'int64', 'Pid', 'pid', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:21.373', '2022-04-28 21:26:21.373', 0, 0);
INSERT INTO `sys_columns` VALUES (253, 59, 'commission', '佣金比例', 'decimal(9,6)', 'decimal.Decimal', 'Commission', 'commission', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:21.471', '2022-04-28 21:26:21.471', 0, 0);
INSERT INTO `sys_columns` VALUES (254, 59, 'remaining', '剩余可质押空间', 'decimal(30,18)', 'decimal.Decimal', 'Remaining', 'remaining', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:21.568', '2022-04-28 21:26:21.568', 0, 0);
INSERT INTO `sys_columns` VALUES (255, 59, 'owner_reward', '质押账号收益', 'decimal(30,18)', 'decimal.Decimal', 'OwnerReward', 'ownerReward', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:21.667', '2022-04-28 21:26:21.667', 0, 0);
INSERT INTO `sys_columns` VALUES (256, 59, 'delegated', '总质押', 'decimal(30,18)', 'decimal.Decimal', 'Delegated', 'delegated', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:21.766', '2022-04-28 21:26:21.766', 0, 0);
INSERT INTO `sys_columns` VALUES (257, 59, 'free_delegation', 'free质押', 'decimal(30,18)', 'decimal.Decimal', 'FreeDelegation', 'freeDelegation', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:21.866', '2022-04-28 21:26:21.866', 0, 0);
INSERT INTO `sys_columns` VALUES (258, 59, 'releasing_stake', '待释放的有效质押', 'decimal(30,18)', 'decimal.Decimal', 'ReleasingStake', 'releasingStake', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 8, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:21.966', '2022-04-28 21:26:21.966', 0, 0);
INSERT INTO `sys_columns` VALUES (259, 59, 'status', '状态（0正常 1删除 2停用 3冻结）', 'char(1)', 'string', 'Status', 'status', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 9, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:22.065', '2022-04-28 21:26:22.065', 0, 0);
INSERT INTO `sys_columns` VALUES (260, 59, 'remkark', '备注', 'varchar(500)', 'string', 'Remkark', 'remkark', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 10, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:22.160', '2022-04-28 21:26:22.160', 0, 0);
INSERT INTO `sys_columns` VALUES (261, 59, 'create_by', '创建者', 'int(11)', 'int64', 'CreateBy', 'createBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 11, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:22.257', '2022-04-28 21:26:22.257', 0, 0);
INSERT INTO `sys_columns` VALUES (262, 59, 'update_by', '更新者', 'int(11)', 'int64', 'UpdateBy', 'updateBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 12, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:22.353', '2022-04-28 21:26:22.353', 0, 0);
INSERT INTO `sys_columns` VALUES (263, 59, 'updated_at', '更新时间', 'datetime', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 13, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:22.449', '2022-04-28 21:26:22.449', 0, 0);
INSERT INTO `sys_columns` VALUES (264, 59, 'created_at', '创建时间', 'datetime', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 14, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-28 21:26:22.546', '2022-04-28 21:26:22.546', 0, 0);
INSERT INTO `sys_columns` VALUES (767, 60, 'id', '主键编码', 'int', 'int64', 'Id', 'id', '1', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 1, '', 1, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:33.213', '2022-04-29 16:54:33.213', 0, 0);
INSERT INTO `sys_columns` VALUES (768, 60, 'current_block_number', '块高度', 'int', 'int64', 'CurrentBlockNumber', 'currentBlockNumber', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 2, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:33.461', '2022-04-29 16:54:33.461', 0, 0);
INSERT INTO `sys_columns` VALUES (769, 60, 'worker_id', 'worker公钥', 'int', 'int64', 'WorkerId', 'workerId', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 3, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:33.733', '2022-04-29 16:54:33.733', 0, 0);
INSERT INTO `sys_columns` VALUES (770, 60, 'current_block_time', '当前块时间', 'datetime', '*time.Time', 'CurrentBlockTime', 'currentBlockTime', '0', '', '0', '1', '1', '1', '1', 'EQ', 'datetime', '', 4, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:33.962', '2022-04-29 16:54:33.962', 0, 0);
INSERT INTO `sys_columns` VALUES (771, 60, 'pid', '质押池编号', 'int', 'int64', 'Pid', 'pid', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 5, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:34.166', '2022-04-29 16:54:34.166', 0, 0);
INSERT INTO `sys_columns` VALUES (772, 60, 'total_reward', '总共挖出', 'decimal(30,18)', 'decimal.Decimal', 'TotalReward', 'totalReward', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 6, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:34.413', '2022-04-29 16:54:34.413', 0, 0);
INSERT INTO `sys_columns` VALUES (773, 60, 'stake', '有效总质押', 'decimal(30,18)', 'decimal.Decimal', 'Stake', 'stake', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 7, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:34.657', '2022-04-29 16:54:34.657', 0, 0);
INSERT INTO `sys_columns` VALUES (774, 60, 'status', '状态（0正常 1删除 2停用 3冻结）', 'char(1)', 'string', 'Status', 'status', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 8, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:34.834', '2022-04-29 16:54:34.834', 0, 0);
INSERT INTO `sys_columns` VALUES (775, 60, 'remkark', '备注', 'varchar(500)', 'string', 'Remkark', 'remkark', '0', '', '0', '1', '1', '1', '1', 'EQ', 'input', '', 9, '', 0, 0, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:34.989', '2022-04-29 16:54:34.989', 0, 0);
INSERT INTO `sys_columns` VALUES (776, 60, 'create_by', '创建者', 'int', 'int64', 'CreateBy', 'createBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 10, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:35.170', '2022-04-29 16:54:35.170', 0, 0);
INSERT INTO `sys_columns` VALUES (777, 60, 'update_by', '更新者', 'int', 'int64', 'UpdateBy', 'updateBy', '0', '', '1', '1', '1', '1', '1', 'EQ', 'input', '', 11, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:35.345', '2022-04-29 16:54:35.345', 0, 0);
INSERT INTO `sys_columns` VALUES (778, 60, 'updated_at', '更新时间', 'datetime', '*time.Time', 'UpdatedAt', 'updatedAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 12, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:35.565', '2022-04-29 16:54:35.565', 0, 0);
INSERT INTO `sys_columns` VALUES (779, 60, 'created_at', '创建时间', 'datetime', '*time.Time', 'CreatedAt', 'createdAt', '0', '', '1', '1', '1', '1', '1', 'EQ', 'datetime', '', 13, '', 0, 1, 0, 0, 0, 1, 0, 0, '', '2022-04-29 16:54:35.778', '2022-04-29 16:54:35.778', 0, 0);
COMMIT;

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `config_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'ConfigName',
  `config_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'ConfigKey',
  `config_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'ConfigValue',
  `config_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'ConfigType',
  `is_frontend` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否前台',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Remark',
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_sys_config_create_by` (`create_by`),
  KEY `idx_sys_config_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_config
-- ----------------------------
BEGIN;
INSERT INTO `sys_config` VALUES (1, '皮肤样式', 'sys_index_skinName', 'skin-green', '0', '0', '主框架页-默认皮肤样式名称:蓝色 skin-blue、绿色 skin-green、紫色 skin-purple、红色 skin-red、黄色 skin-yellow', 1, 1, '2021-05-13 19:56:37.913', '2021-06-05 13:50:13.123');
INSERT INTO `sys_config` VALUES (2, '初始密码', 'sys_user_initPassword', '123456', '0', '0', '用户管理-账号初始密码:123456', 1, 1, '2021-05-13 19:56:37.913', '2021-05-13 19:56:37.913');
INSERT INTO `sys_config` VALUES (3, '侧栏主题', 'sys_index_sideTheme', 'theme-dark', '0', '0', '主框架页-侧边栏主题:深色主题theme-dark，浅色主题theme-light', 1, 1, '2021-05-13 19:56:37.913', '2021-05-13 19:56:37.913');
INSERT INTO `sys_config` VALUES (4, '系统名称', 'sys_app_name', 'towin管理系统', '0', '0', '', 1, 0, '2021-03-17 08:52:06.067', '2021-11-18 14:49:42.953');
INSERT INTO `sys_config` VALUES (5, '系统logo', 'sys_app_logo', 'http://www.wjblog.top/images/my_head-touch-icon-next.png', '0', '0', '', 1, 0, '2021-03-17 08:53:19.462', '2021-03-17 08:53:19.462');
INSERT INTO `sys_config` VALUES (17, 'App OSS Bucket', 'app_oss_bucket', '请自行配置', '1', '0', '', 0, 0, '2021-08-13 14:36:23.492', '2022-03-02 12:28:06.075');
INSERT INTO `sys_config` VALUES (18, 'App OSS AccessKeyId', 'app_oss_access_key_id', '请自行配置', '1', '0', '', 0, 0, '2021-08-13 14:37:15.218', '2022-03-02 12:27:50.187');
INSERT INTO `sys_config` VALUES (19, 'App OSS AccessKeySecret', 'app_oss_access_key_secret', '请自行配置', '1', '0', '', 0, 0, '2021-08-13 14:37:59.627', '2022-03-02 12:27:41.670');
INSERT INTO `sys_config` VALUES (20, 'App OSS Endpoint', 'app_oss_endpoint', '请自行配置', '1', '0', '', 0, 0, '2021-08-13 14:38:49.603', '2022-03-02 12:27:26.938');
INSERT INTO `sys_config` VALUES (21, 'App OSS 根目录', 'app_oss_root_path', 'file/', '1', '0', '', 0, 0, '2021-08-13 14:39:30.655', '2021-08-13 14:39:30.655');
INSERT INTO `sys_config` VALUES (26, '中文通用短信模板', 'sys_sms_template_cn', '请自行配置', '0', '0', '', 0, 0, '2021-08-24 15:16:02.439', '2021-08-24 15:16:02.439');
INSERT INTO `sys_config` VALUES (27, '英文通用短信模板', 'sys_sms_template_en', '请自行配置', '0', '0', '', 0, 0, '2021-08-24 15:16:32.819', '2022-03-16 14:28:01.864');
INSERT INTO `sys_config` VALUES (28, '短信是否开启', 'sys_sms_open', '1', '1', '0', '0-开启  1-关闭', 0, 0, '2021-08-24 15:34:22.736', '2022-03-18 15:27:18.067');
INSERT INTO `sys_config` VALUES (29, '短信签名', 'sys_sms_sign_name', '请自行配置', '0', '0', '', 0, 0, '2021-08-24 15:53:47.056', '2021-08-24 15:53:47.056');
INSERT INTO `sys_config` VALUES (30, '短信secret', 'sys_sms_secret', '请自行配置', '0', '0', '', 0, 1, '2021-08-24 15:54:31.280', '2022-04-25 11:51:35.880');
INSERT INTO `sys_config` VALUES (31, '短信Key', 'sys_sms_key', '请自行配置', '0', '0', '', 0, 0, '2021-08-24 15:57:19.700', '2021-08-24 15:57:19.700');
INSERT INTO `sys_config` VALUES (39, '邮箱是否开启', 'sys_email_open', '1', '0', '0', '0-开启 1-关闭', 0, 0, '2021-09-01 17:23:27.538', '2022-03-23 14:54:19.123');
INSERT INTO `sys_config` VALUES (40, '邮箱配置-服务商域名', 'msg_email_smtp_server', '请自行配置', '0', '0', '', 0, 0, '2021-09-01 17:58:27.908', '2021-09-01 17:58:27.908');
INSERT INTO `sys_config` VALUES (41, '邮箱配置-发送人邮箱', 'msg_email_send_address', '请自行配置', '0', '0', '', 0, 0, '2021-09-01 17:59:41.967', '2021-09-01 17:59:41.967');
INSERT INTO `sys_config` VALUES (42, '邮箱配置-授权码(密码)', 'msg_email_auth', '请自行配置', '0', '0', '', 0, 0, '2021-09-01 18:00:48.655', '2021-09-01 18:00:48.655');
INSERT INTO `sys_config` VALUES (43, '邮箱配置-默认主题', 'msg_email_send_subject', '请自行配置', '0', '0', '', 0, 0, '2021-09-01 18:01:27.146', '2021-09-01 18:01:27.146');
INSERT INTO `sys_config` VALUES (44, '邮箱配置-发送人姓名', 'msg_email_send_username', '请自行配置', '0', '0', '', 0, 0, '2021-09-01 18:02:01.710', '2021-09-01 18:02:01.710');
INSERT INTO `sys_config` VALUES (45, '邮箱配置-默认内容', 'msg_email_send_content', '验证码5分钟有效,验证码提供他人可能导致账号被盗，请勿转发或泄露,您的验证码是:', '0', '0', '', 0, 0, '2021-09-01 18:02:36.898', '2021-09-01 18:02:36.898');
INSERT INTO `sys_config` VALUES (46, '邮箱配置-端口号', 'msg_email_port', '465', '0', '0', '', 0, 0, '2021-09-01 18:03:05.122', '2021-09-01 18:03:05.122');
INSERT INTO `sys_config` VALUES (47, '邮箱配置-是否https通信', 'msg_email_https', '0', '0', '0', '0-https 1-http', 0, 0, '2021-09-02 09:13:17.875', '2021-09-02 09:13:17.875');
INSERT INTO `sys_config` VALUES (90, '单次excel导出数据量', 'sys_max_export_size', '10000', 'N', '1', '', 0, 0, '2021-07-28 16:53:48.330', '2022-02-24 11:49:14.810');
COMMIT;

-- ----------------------------
-- Table structure for sys_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_dept`;
CREATE TABLE `sys_dept` (
  `dept_id` bigint NOT NULL AUTO_INCREMENT,
  `parent_id` bigint DEFAULT NULL,
  `dept_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `dept_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sort` tinyint DEFAULT NULL,
  `leader` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `phone` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `status` tinyint DEFAULT NULL,
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`dept_id`),
  KEY `idx_sys_dept_create_by` (`create_by`),
  KEY `idx_sys_dept_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_dept
-- ----------------------------
BEGIN;
INSERT INTO `sys_dept` VALUES (1, 0, '/0/1/', 'Admin', 0, 'admin', '13711111111', '', 2, 1, 1, '2021-05-13 19:56:37.913', '2022-05-14 11:20:25.321');
INSERT INTO `sys_dept` VALUES (7, 1, '/0/1/7/', '研发部', 1, 'admin', '13711111111', '', 2, 1, 1, '2021-05-13 19:56:37.913', '2022-05-14 11:20:33.581');
INSERT INTO `sys_dept` VALUES (8, 1, '/0/1/8/', '运维部', 1, 'admin', '13711111111', '', 1, 1, 1, '2021-05-13 19:56:37.913', '2022-05-14 11:20:44.234');
INSERT INTO `sys_dept` VALUES (9, 1, '/0/1/9/', '客服部', 0, 'admin', '13711111111', '', 2, 1, 1, '2021-05-13 19:56:37.913', '2022-05-14 11:20:49.571');
INSERT INTO `sys_dept` VALUES (10, 1, '/0/1/10/', '人力资源', 3, 'admin', '13711111111', '', 1, 1, 1, '2021-05-13 19:56:37.913', '2022-05-14 11:20:53.395');
INSERT INTO `sys_dept` VALUES (13, 11, '/0/11/13/', '云', 10, '干活', '', '', 2, 0, 0, '2021-11-18 14:59:16.359', '2021-11-18 14:59:16.360');
INSERT INTO `sys_dept` VALUES (14, 1, '/0/1/14/', '市场', 10, '市场', '', '', 2, 0, 0, '2021-12-02 10:13:37.729', '2021-12-02 10:13:37.730');
INSERT INTO `sys_dept` VALUES (15, 1, '/0/1/15/', '财务', 10, '财务', '', '', 2, 0, 0, '2021-12-02 10:15:57.395', '2021-12-02 10:15:57.396');
COMMIT;

-- ----------------------------
-- Table structure for sys_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_data`;
CREATE TABLE `sys_dict_data` (
  `dict_code` bigint NOT NULL AUTO_INCREMENT,
  `dict_sort` bigint DEFAULT NULL,
  `dict_label` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `dict_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `dict_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `css_class` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `list_class` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_default` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `default` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`dict_code`),
  KEY `idx_sys_dict_data_create_by` (`create_by`),
  KEY `idx_sys_dict_data_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_dict_data
-- ----------------------------
BEGIN;
INSERT INTO `sys_dict_data` VALUES (1, 0, '正常', '2', 'sys_normal_disable', '', '', '', '0', '', '系统正常', 1, 1, '2021-05-13 19:56:37.914', '2022-04-25 00:42:38.282');
INSERT INTO `sys_dict_data` VALUES (2, 0, '停用', '1', 'sys_normal_disable', '', '', '', '0', '', '系统停用', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (3, 0, '男', '0', 'sys_user_sex', '', '', '', '0', '', '性别男', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (4, 0, '女', '1', 'sys_user_sex', '', '', '', '0', '', '性别女', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (5, 0, '未知', '2', 'sys_user_sex', '', '', '', '0', '', '性别未知', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (6, 0, '显示', '0', 'sys_show_hide', '', '', '', '0', '', '显示菜单', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (7, 0, '隐藏', '1', 'sys_show_hide', '', '', '', '0', '', '隐藏菜单', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (8, 0, '是', '0', 'sys_yes_no', '', '', '', '0', '', '系统默认是', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (9, 0, '否', '1', 'sys_yes_no', '', '', '', '0', '', '系统默认否', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (14, 0, '通知', '1', 'sys_notice_type', '', '', '', '0', '', '通知', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (15, 0, '公告', '2', 'sys_notice_type', '', '', '', '0', '', '公告', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (16, 0, '正常', '2', 'sys_common_status', '', '', '', '0', '', '正常状态', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (17, 0, '关闭', '1', 'sys_common_status', '', '', '', '0', '', '关闭状态', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (18, 0, '新增', '1', 'sys_oper_type', '', '', '', '0', '', '新增操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (19, 0, '修改', '2', 'sys_oper_type', '', '', '', '0', '', '修改操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (20, 0, '删除', '3', 'sys_oper_type', '', '', '', '0', '', '删除操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (21, 0, '授权', '4', 'sys_oper_type', '', '', '', '0', '', '授权操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (22, 0, '导出', '5', 'sys_oper_type', '', '', '', '0', '', '导出操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (23, 0, '导入', '6', 'sys_oper_type', '', '', '', '0', '', '导入操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (24, 0, '强退', '7', 'sys_oper_type', '', '', '', '0', '', '强退操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (25, 0, '生成代码', '8', 'sys_oper_type', '', '', '', '0', '', '生成操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (26, 0, '清空数据', '9', 'sys_oper_type', '', '', '', '0', '', '清空操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (27, 0, '成功', '0', 'sys_notice_status', '', '', '', '0', '', '成功状态', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (28, 0, '失败', '1', 'sys_notice_status', '', '', '', '0', '', '失败状态', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (29, 0, '登录', '10', 'sys_oper_type', '', '', '', '0', '', '登录操作', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (30, 0, '退出', '11', 'sys_oper_type', '', '', '', '0', '', '', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (31, 0, '获取验证码', '12', 'sys_oper_type', '', '', '', '0', '', '获取验证码', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_data` VALUES (32, 0, '正常', '0', 'sys_status', '', '', '', '0', '', '', 0, 0, '2021-07-09 11:40:00.705', '2021-07-09 11:40:00.705');
INSERT INTO `sys_dict_data` VALUES (33, 0, '停用', '1', 'sys_status', '', '', '', '0', '', '', 0, 0, '2021-07-09 11:40:14.328', '2021-07-09 11:40:14.328');
INSERT INTO `sys_dict_data` VALUES (136, 0, '安卓', '0', 'app_platform', '', '', '', '2', '', '', 0, 0, '2021-08-13 13:35:38.598', '2021-08-13 13:35:38.598');
INSERT INTO `sys_dict_data` VALUES (137, 0, 'IOS', '1', 'app_platform', '', '', '', '2', '', '', 0, 0, '2021-08-13 13:35:51.042', '2021-08-13 13:35:51.042');
INSERT INTO `sys_dict_data` VALUES (138, 0, '类型1', '0', 'app_type', '', '', '', '2', '', '', 0, 0, '2021-08-13 13:37:06.741', '2021-08-13 13:37:06.741');
INSERT INTO `sys_dict_data` VALUES (139, 0, '类型2', '1', 'app_type', '', '', '', '2', '', '', 0, 0, '2021-08-13 13:37:18.879', '2021-08-13 13:37:18.879');
INSERT INTO `sys_dict_data` VALUES (140, 0, '类型3', '2', 'app_type', '', '', '', '2', '', '', 0, 0, '2021-08-13 13:37:39.156', '2021-08-13 13:37:39.156');
INSERT INTO `sys_dict_data` VALUES (141, 0, 'OSS', '0', 'app_download_type', '', '', '', '2', '', '', 0, 0, '2021-08-13 14:02:33.024', '2021-08-13 14:02:33.024');
INSERT INTO `sys_dict_data` VALUES (142, 0, '外链', '1', 'app_download_type', '', '', '', '2', '', '', 0, 0, '2021-08-13 14:02:43.703', '2021-08-13 14:02:43.703');
INSERT INTO `sys_dict_data` VALUES (145, 0, '已发布', '0', 'app_status', '', '', '', '2', '', '', 0, 0, '2021-12-09 12:42:46.735', '2021-12-09 12:42:46.735');
INSERT INTO `sys_dict_data` VALUES (146, 0, '待发布', '1', 'app_status', '', '', '', '2', '', '', 0, 0, '2021-12-09 12:42:53.919', '2021-12-09 12:42:53.919');
INSERT INTO `sys_dict_data` VALUES (178, 0, 'SYS', '0', 'sys_api_type', '', '', '', '0', '', '', 1, 1, '2022-04-25 23:58:23.962', '2022-04-25 23:58:23.962');
INSERT INTO `sys_dict_data` VALUES (179, 0, 'BUS', '1', 'sys_api_type', '', '', '', '0', '', '', 1, 1, '2022-04-25 23:58:40.914', '2022-04-25 23:58:40.914');
INSERT INTO `sys_dict_data` VALUES (180, 0, 'GET', 'GET', 'sys_request_type', '', '', '', '0', '', '', 1, 1, '2022-04-26 00:03:26.071', '2022-04-26 00:03:26.071');
INSERT INTO `sys_dict_data` VALUES (181, 0, 'POST', 'POST', 'sys_request_type', '', '', '', '0', '', '', 1, 1, '2022-04-26 00:03:40.362', '2022-04-26 00:03:40.362');
INSERT INTO `sys_dict_data` VALUES (182, 0, 'DELETE', 'DELETE', 'sys_request_type', '', '', '', '0', '', '', 1, 1, '2022-04-26 00:03:49.343', '2022-04-26 00:03:49.343');
INSERT INTO `sys_dict_data` VALUES (183, 0, 'PUT', 'PUT', 'sys_request_type', '', '', '', '0', '', '', 1, 1, '2022-04-26 00:04:05.573', '2022-04-26 00:04:05.573');
INSERT INTO `sys_dict_data` VALUES (184, 0, 'HEAD', 'HEAD', 'sys_request_type', '', '', '', '0', '', '', 1, 1, '2022-04-26 00:07:01.600', '2022-04-26 00:07:01.600');
COMMIT;

-- ----------------------------
-- Table structure for sys_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type` (
  `dict_id` bigint NOT NULL AUTO_INCREMENT,
  `dict_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `dict_type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`dict_id`),
  KEY `idx_sys_dict_type_create_by` (`create_by`),
  KEY `idx_sys_dict_type_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_dict_type
-- ----------------------------
BEGIN;
INSERT INTO `sys_dict_type` VALUES (1, '系统开关', 'sys_normal_disable', '0', '系统开关列表', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_type` VALUES (2, '用户性别', 'sys_user_sex', '0', '用户性别列表', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_type` VALUES (3, '菜单状态', 'sys_show_hide', '0', '菜单状态列表', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_type` VALUES (4, '系统是否', 'sys_yes_no', '0', '系统是否列表', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_type` VALUES (7, '通知类型', 'sys_notice_type', '0', '通知类型列表', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_type` VALUES (8, '系统状态', 'sys_common_status', '0', '登录状态列表', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_type` VALUES (9, '操作类型', 'sys_oper_type', '0', '操作类型列表', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_type` VALUES (10, '通知状态', 'sys_notice_status', '0', '通知状态列表', 1, 1, '2021-05-13 19:56:37.914', '2021-05-13 19:56:37.914');
INSERT INTO `sys_dict_type` VALUES (11, '基本状态', 'sys_status', '0', '基本通用状态', 0, 0, '2021-07-09 11:39:20.625', '2021-07-09 11:39:29.997');
INSERT INTO `sys_dict_type` VALUES (51, 'App状态', 'app_status', '2', '', 0, 0, '2021-12-09 12:42:30.884', '2021-12-09 12:42:30.884');
INSERT INTO `sys_dict_type` VALUES (59, 'App类型', 'app_type', '0', 'app属性', 0, 1, '2021-08-13 13:36:39.857', '2022-04-24 21:30:18.323');
INSERT INTO `sys_dict_type` VALUES (60, 'App下载类型', 'app_download_type', '0', '', 0, 0, '2021-08-13 14:02:03.384', '2021-08-13 14:02:03.384');
INSERT INTO `sys_dict_type` VALUES (61, 'App状态', 'app_status', '0', '', 0, 0, '2021-12-09 12:42:30.884', '2021-12-09 12:42:30.884');
INSERT INTO `sys_dict_type` VALUES (65, '系统接口类型', 'sys_api_type', '0', '系统', 1, 1, '2022-04-25 23:57:17.211', '2022-04-25 23:57:17.211');
INSERT INTO `sys_dict_type` VALUES (66, '系统请求类型', 'sys_request_type', '0', '', 1, 1, '2022-04-26 00:03:10.770', '2022-04-26 00:03:10.770');
COMMIT;

-- ----------------------------
-- Table structure for sys_login_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_login_log`;
CREATE TABLE `sys_login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `username` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用户名',
  `status` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '状态',
  `ipaddr` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'ip地址',
  `login_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '归属地',
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '浏览器',
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '系统',
  `platform` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '固件',
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '登录时间',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  `msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '信息',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`id`),
  KEY `idx_sys_login_log_create_by` (`create_by`),
  KEY `idx_sys_login_log_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_login_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `menu_id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `title` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `icon` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `path` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `paths` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `menu_type` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `action` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `parent_id` smallint DEFAULT NULL,
  `keep_alive` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否缓存',
  `breadcrumb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `component` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sort` int DEFAULT NULL,
  `hidden` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_frame` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '0',
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`menu_id`),
  KEY `idx_sys_menu_create_by` (`create_by`),
  KEY `idx_sys_menu_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=836 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
BEGIN;
INSERT INTO `sys_menu` VALUES (2, 'sys', '系统管理', 'api-server', 'sys', '/0/2', 'M', '无', '', 0, '1', '', 'view/sys/index.vue', 300, '0', '1', 0, 1, '2021-05-20 21:58:45.679', '2022-05-12 11:12:14.892');
INSERT INTO `sys_menu` VALUES (3, 'sysuser', '用户管理', 'user', 'sysuser', '/0/2/3', 'C', '无', '', 2, '1', '', 'view/sys/user/index.vue', 10, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2022-05-12 11:12:14.892');
INSERT INTO `sys_menu` VALUES (43, '', '新增管理员1', 'app-group-fill', '', '/0/2/3/43', 'F', 'POST', 'admin:sysUser:add', 3, '1', '', '', 10, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2022-05-12 11:12:14.892');
INSERT INTO `sys_menu` VALUES (44, '', '查询管理员', 'app-group-fill', '', '/0/2/3/44', 'F', 'GET', 'admin:sysUser:query', 3, '1', '', '', 40, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2022-05-12 11:12:14.892');
INSERT INTO `sys_menu` VALUES (45, '', '修改管理员', 'app-group-fill', '', '/0/2/3/45', 'F', 'PUT', 'admin:sysUser:edit', 3, '1', '', '', 30, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2022-05-12 11:12:14.892');
INSERT INTO `sys_menu` VALUES (46, '', '删除管理员', 'app-group-fill', '', '/0/2/3/46', 'F', 'DELETE', 'admin:sysUser:remove', 3, '1', '', '', 20, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2022-05-12 11:12:14.892');
INSERT INTO `sys_menu` VALUES (51, 'menu', '菜单管理', 'tree-table', 'menu', '/0/2/51', 'C', '无', 'admin:sysMenu:list', 2, '1', '', 'view/sys/menu/index.vue', 30, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (52, 'role', '角色管理', 'peoples', 'role', '', 'C', '无', 'admin:sysRole:list', 2, '1', '', 'view/sys/role/index.vue', 20, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (56, 'dept', '部门管理', 'tree', 'dept', '', 'C', '无', '', 2, '1', '', 'view/sys/dept/index.vue', 40, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (57, 'syspost', '岗位管理', 'pass', 'syspost', '/0/2/57', 'C', '无', 'admin:sysPost:list', 2, '1', '', 'view/sys/post/index.vue', 50, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (58, 'dicttype', '字典管理', 'education', 'dicttype', '/0/2/58', 'C', '无', 'admin:sysDictType:list', 2, '1', '', 'view/sys/dicttype/index.vue', 60, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (59, 'dictdata', '字典数据', 'education', 'dictdata', '/0/2/59', 'C', '无', 'admin:sysDictData:list', 2, '0', '', 'view/sys/dictdata/index.vue', 100, '1', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (62, 'configmgr', '参数管理', 'swagger', 'configmgr', '/0/2/62', 'C', '无', 'admin:sysConfig:list', 2, '1', '', 'view/sys/config/index.vue', 70, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (212, 'loginlog', '登录日志', 'logininfor', 'loginlog', '', 'C', '', 'admin:sysLoginLog:list', 2, '1', '', 'view/sys/loginlog/index.vue', 90, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (216, 'operalog', '操作日志', 'skill', 'operalog', '', 'C', '', 'admin:sysOperLog:list', 2, '1', '', 'view/sys/operalog/index.vue', 120, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (220, '', '新增菜单', 'app-group-fill', '', '/0/2/51/220', 'F', '', 'admin:sysMenu:add', 51, '1', '', '', 1, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (221, '', '修改菜单', 'app-group-fill', '', '/0/2/51/221', 'F', '', 'admin:sysMenu:edit', 51, '1', '', '', 1, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (222, '', '查询菜单', 'app-group-fill', '', '/0/2/51/222', 'F', '', 'admin:sysMenu:query', 51, '1', '', '', 1, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (223, '', '删除菜单', 'app-group-fill', '', '/0/2/51/223', 'F', '', 'admin:sysMenu:remove', 51, '1', '', '', 1, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (224, '', '新增角色', 'app-group-fill', '', '/0/2/52/224', 'F', '', 'admin:sysRole:add', 52, '1', '', '', 1, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (225, '', '查询角色', 'app-group-fill', '', '/0/2/52/225', 'F', '', 'admin:sysRole:query', 52, '1', '', '', 1, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (226, '', '修改角色', 'app-group-fill', '', '/0/2/52/226', 'F', '', 'admin:sysRole:update', 52, '1', '', '', 1, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (227, '', '删除角色', 'app-group-fill', '', '/0/2/52/227', 'F', '', 'admin:sysRole:remove', 52, '1', '', '', 1, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (228, '', '查询部门', 'app-group-fill', '', '/0/2/56/228', 'F', '', 'admin:sysDept:query', 56, '1', '', '', 40, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (229, '', '新增部门', 'app-group-fill', '', '/0/2/56/229', 'F', '', 'admin:sysDept:add', 56, '1', '', '', 10, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (230, '', '修改部门', 'app-group-fill', '', '/0/2/56/230', 'F', '', 'admin:sysDept:edit', 56, '1', '', '', 30, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (231, '', '删除部门', 'app-group-fill', '', '/0/2/56/231', 'F', '', 'admin:sysDept:remove', 56, '1', '', '', 20, '0', '1', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (232, '', '查询岗位', 'app-group-fill', '', '/0/2/57/232', 'F', '', 'admin:sysPost:query', 57, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (233, '', '新增岗位', 'app-group-fill', '', '/0/2/57/233', 'F', '', 'admin:sysPost:add', 57, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (234, '', '修改岗位', 'app-group-fill', '', '/0/2/57/234', 'F', '', 'admin:sysPost:edit', 57, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (235, '', '删除岗位', 'app-group-fill', '', '/0/2/57/235', 'F', '', 'admin:sysPost:remove', 57, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (236, '', '查询字典', 'app-group-fill', '', '/0/2/58/236', 'F', '', 'admin:sysDictType:query', 58, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (237, '', '新增类型', 'app-group-fill', '', '/0/2/58/237', 'F', '', 'admin:sysDictType:add', 58, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (238, '', '修改类型', 'app-group-fill', '', '/0/2/58/238', 'F', '', 'admin:sysDictType:edit', 58, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (239, '', '删除类型', 'app-group-fill', '', '/0/2/58/239', 'F', '', 'system:sysdicttype:remove', 58, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (240, '', '查询数据', 'app-group-fill', '', '/0/2/59/240', 'F', '', 'admin:sysDictData:query', 59, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (241, '', '新增数据', 'app-group-fill', '', '/0/2/59/241', 'F', '', 'admin:sysDictData:add', 59, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (242, '', '修改数据', 'app-group-fill', '', '/0/2/59/242', 'F', '', 'admin:sysDictData:edit', 59, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (243, '', '删除数据', 'app-group-fill', '', '/0/2/59/243', 'F', '', 'admin:sysDictData:remove', 59, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (244, '', '查询参数', 'app-group-fill', '', '/0/2/62/244', 'F', '', 'admin:sysConfig:query', 62, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (245, '', '新增参数', 'app-group-fill', '', '/0/2/62/245', 'F', '', 'admin:sysConfig:add', 62, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (246, '', '修改参数', 'app-group-fill', '', '/0/2/62/246', 'F', '', 'admin:sysConfig:edit', 62, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (247, '', '删除参数', 'app-group-fill', '', '/0/2/62/247', 'F', '', 'admin:sysConfig:remove', 62, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (248, '', '查询登录日志', 'app-group-fill', '', '/0/2/211/212/248', 'F', '', 'admin:sysLoginLog:query', 212, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (249, '', '删除登录日志', 'app-group-fill', '', '/0/2/211/212/249', 'F', '', 'admin:sysLoginLog:remove', 212, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (250, '', '查询操作日志', 'app-group-fill', '', '/0/2/211/216/250', 'F', '', 'admin:sysOperLog:query', 216, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (251, '', '删除操作日志', 'app-group-fill', '', '/0/2/211/216/251', 'F', '', 'admin:sysOperLog:remove', 216, '1', '', '', 0, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (261, 'gen', '代码生成', 'code', 'gen', '', 'C', '', '', 537, '1', '', 'view/sys/tools/gen/index.vue', 2, '0', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-09-01 09:37:52.262');
INSERT INTO `sys_menu` VALUES (262, 'editTable', '代码生成修改', 'build', 'editTable', '/0/60/262', 'C', '', '', 537, '0', '', 'view/sys/tools/gen/editTable.vue', 100, '1', '1', 1, 1, '2020-04-11 15:52:48.000', '2021-09-01 09:38:04.854');
INSERT INTO `sys_menu` VALUES (269, 'monitor', '服务监控', 'druid', 'monitor', '/0/60/269', 'C', '', 'sys:monitor:list', 537, '1', '', 'view/sys/tools/monitor/monitor.vue', 0, '0', '1', 1, 1, '2020-04-14 00:28:19.000', '2021-06-16 21:26:12.446');
INSERT INTO `sys_menu` VALUES (270, 'config', '系统配置', 'druid', 'config', '', 'C', '', 'sys:config:list', 537, '1', '', 'view/sys/tools/config/config.vue', 0, '0', '1', 1, 1, '2020-04-14 00:28:19.000', '2021-06-16 21:26:12.446');
INSERT INTO `sys_menu` VALUES (528, 'sysapi', '接口管理', 'api-doc', 'sysapi', '/0/527/528', 'C', '无', 'admin:sysApi:list', 2, '1', '', 'view/sys/api/index.vue', 0, '0', '0', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (529, '', '查询接口', 'app-group-fill', '', '/0/527/528/529', 'F', '无', 'admin:sysApi:query', 528, '1', '', '', 40, '0', '0', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (531, '', '修改接口', 'app-group-fill', '', '/0/527/528/531', 'F', '无', 'admin:sysApi:edit', 528, '1', '', '', 30, '0', '0', 0, 1, '2021-05-20 22:08:44.526', '2021-11-29 15:39:04.167');
INSERT INTO `sys_menu` VALUES (537, 'tools', '系统工具', 'system-tools', 'tools', '', 'M', '', '', 0, '1', '', 'view/sys/tools/index.vue', 330, '0', '1', 1, 1, '2021-05-21 11:13:32.166', '2021-07-22 16:04:16.515');
INSERT INTO `sys_menu` VALUES (772, 'filemgr', '文件管理', 'base-info', 'filemgr', '', 'M', '无', '', 0, '1', '', 'view/plugins/filemgr/index.vue', 270, '0', '0', 1, 1, '2021-08-13 14:19:10.808', '2021-08-13 14:21:13.597');
INSERT INTO `sys_menu` VALUES (773, 'app', 'App管理', 'job', 'app', '', 'C', '无', 'filemgr:app:list', 772, '1', '', 'view/plugins/filemgr/app/index.vue', 0, '0', '0', 1, 1, '2021-08-13 14:19:10.991', '2021-08-13 14:21:36.898');
INSERT INTO `sys_menu` VALUES (774, '', '分页获取App管理', '', 'qyc_turing_app_manager', '', 'F', '无', 'towin:appManager:query', 773, '1', '', '', 0, '0', '0', 1, 1, '2021-08-13 14:19:11.187', '2021-11-29 15:32:34.722');
INSERT INTO `sys_menu` VALUES (775, '', '创建App管理', '', 'qyc_turing_app_manager', '', 'F', '无', 'towin:appManager:add', 773, '1', '', '', 0, '0', '0', 1, 1, '2021-08-13 14:19:11.371', '2021-11-29 15:32:45.318');
INSERT INTO `sys_menu` VALUES (776, '', '修改App管理', '', 'qyc_turing_app_manager', '', 'F', '无', 'towin:appManager:edit', 773, '1', '', '', 0, '0', '0', 1, 1, '2021-08-13 14:19:11.592', '2021-11-29 15:33:35.221');
INSERT INTO `sys_menu` VALUES (777, '', '删除App管理', '', 'qyc_turing_app_manager', '', 'F', '无', 'towin:appManager:remove', 773, '1', '', '', 0, '0', '0', 1, 1, '2021-08-13 14:19:11.735', '2021-11-29 15:33:48.780');
INSERT INTO `sys_menu` VALUES (778, 'content', '内容管理', 'clipboard', 'content', '', 'M', '无', '', 0, '1', '', 'view/plugins/content/index.vue', 240, '0', '0', 1, 1, '2021-08-16 18:01:19.907', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (779, 'category', '内容分类', 'err-list', 'category', '', 'C', '无', 'content:category:list', 778, '1', '', 'view/plugins/content/category/index.vue', 30, '0', '0', 1, 1, '2021-08-16 18:01:20.085', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (780, '', '分页获取内容分类', '', 'content_category', '', 'F', '无', 'content:category:query', 779, '1', '', '', 0, '0', '0', 1, 1, '2021-08-16 18:01:20.236', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (781, '', '创建内容分类', '', 'content_category', '', 'F', '无', 'content:category:add', 779, '1', '', '', 0, '0', '0', 1, 1, '2021-08-16 18:01:20.377', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (782, '', '修改内容分类', '', 'content_category', '', 'F', '无', 'content:category:edit', 779, '1', '', '', 0, '0', '0', 1, 1, '2021-08-16 18:01:20.518', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (783, '', '删除内容分类', '', 'content_category', '', 'F', '无', 'content:category:remove', 779, '1', '', '', 0, '0', '0', 1, 1, '2021-08-16 18:01:20.661', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (785, 'article', '文章管理', 'pass', 'article', '', 'C', '无', 'content:article:list', 778, '1', '', 'view/plugins/content/article/index.vue', 60, '0', '0', 1, 1, '2021-08-17 09:39:29.277', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (786, '', '分页获取富文本内容', '', 'content_article', '', 'F', '无', 'content:article:query', 785, '1', '', '', 0, '0', '0', 1, 1, '2021-08-17 09:39:29.441', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (787, '', '创建富文本内容', '', 'content_article', '', 'F', '无', 'content:article:add', 785, '1', '', '', 0, '0', '0', 1, 1, '2021-08-17 09:39:29.601', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (788, '', '修改富文本内容', '', 'content_article', '', 'F', '无', 'content:article:edit', 785, '1', '', '', 0, '0', '0', 1, 1, '2021-08-17 09:39:29.745', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (789, '', '删除富文本内容', '', 'content_article', '', 'F', '无', 'content:article:remove', 785, '1', '', '', 0, '0', '0', 1, 1, '2021-08-17 09:39:30.461', '2021-11-29 15:37:35.336');
INSERT INTO `sys_menu` VALUES (827, 'announcement', '公告管理', 'pass', 'announcement', '', 'C', '无', 'content:announcement:list', 778, '1', '', 'view/plugins/content/announcement/index.vue', 90, '0', '0', 1, 1, '2021-12-22 10:25:47.877', '2021-12-22 10:28:50.918');
INSERT INTO `sys_menu` VALUES (828, '', '分页获取公告管理', '', 'content_announcement', '', 'F', '无', 'content:announcement:query', 827, '1', '', '', 0, '0', '0', 1, 1, '2021-12-22 10:25:48.000', '2021-12-22 10:25:48.000');
INSERT INTO `sys_menu` VALUES (829, '', '创建公告管理', '', 'content_announcement', '', 'F', '无', 'content:announcement:add', 827, '1', '', '', 0, '0', '0', 1, 1, '2021-12-22 10:25:48.092', '2021-12-22 10:25:48.092');
INSERT INTO `sys_menu` VALUES (830, '', '修改公告管理', '', 'content_announcement', '', 'F', '无', 'content:announcement:edit', 827, '1', '', '', 0, '0', '0', 1, 1, '2021-12-22 10:25:48.180', '2021-12-22 10:25:48.180');
INSERT INTO `sys_menu` VALUES (831, '', '删除公告管理', '', 'content_announcement', '', 'F', '无', 'content:announcement:remove', 827, '1', '', '', 0, '0', '0', 1, 1, '2021-12-22 10:25:48.268', '2021-12-22 10:25:48.268');
COMMIT;

-- ----------------------------
-- Table structure for sys_menu_api_rule
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu_api_rule`;
CREATE TABLE `sys_menu_api_rule` (
  `sys_menu_menu_id` bigint NOT NULL,
  `sys_api_id` bigint NOT NULL COMMENT '主键编码',
  PRIMARY KEY (`sys_menu_menu_id`,`sys_api_id`),
  KEY `fk_sys_menu_api_rule_sys_api` (`sys_api_id`),
  CONSTRAINT `fk_sys_menu_api_rule_sys_api` FOREIGN KEY (`sys_api_id`) REFERENCES `sys_api` (`id`),
  CONSTRAINT `fk_sys_menu_api_rule_sys_menu` FOREIGN KEY (`sys_menu_menu_id`) REFERENCES `sys_menu` (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_menu_api_rule
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_migration
-- ----------------------------
DROP TABLE IF EXISTS `sys_migration`;
CREATE TABLE `sys_migration` (
  `version` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `apply_time` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_migration
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_opera_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_opera_log`;
CREATE TABLE `sys_opera_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作模块',
  `business_type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作类型',
  `business_types` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'BusinessTypes',
  `method` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '函数',
  `request_method` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '请求方式',
  `operator_type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作类型',
  `oper_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作者',
  `dept_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '部门名称',
  `oper_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '访问地址',
  `oper_ip` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '客户端ip',
  `oper_location` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '访问位置',
  `oper_param` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '请求参数',
  `status` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作状态',
  `oper_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '操作时间',
  `json_result` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '返回数据',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  `latency_time` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '耗时',
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'ua',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`id`),
  KEY `idx_sys_opera_log_create_by` (`create_by`),
  KEY `idx_sys_opera_log_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=10892 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_opera_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_post
-- ----------------------------
DROP TABLE IF EXISTS `sys_post`;
CREATE TABLE `sys_post` (
  `post_id` int NOT NULL AUTO_INCREMENT,
  `post_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `post_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sort` tinyint DEFAULT NULL,
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`post_id`) USING BTREE,
  KEY `idx_sys_post_create_by` (`create_by`),
  KEY `idx_sys_post_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_post
-- ----------------------------
BEGIN;
INSERT INTO `sys_post` VALUES (1, '首席执行官', 'CEO', 0, '0', '首席执行官', 1, 1, '2021-05-13 19:56:37.913', '2021-05-13 19:56:37.913');
INSERT INTO `sys_post` VALUES (2, '首席技术执行官', 'CTO', 2, '0', '首席技术执行官', 1, 1, '2021-05-13 19:56:37.913', '2021-05-13 19:56:37.913');
INSERT INTO `sys_post` VALUES (3, '首席运营官', 'COO', 3, '0', '测试工程师', 1, 1, '2021-05-13 19:56:37.913', '2021-05-13 19:56:37.913');
COMMIT;

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `role_id` bigint NOT NULL AUTO_INCREMENT,
  `role_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `status` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `role_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `role_sort` bigint DEFAULT NULL,
  `flag` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `admin` tinyint(1) DEFAULT NULL,
  `data_scope` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`role_id`),
  KEY `idx_sys_role_create_by` (`create_by`),
  KEY `idx_sys_role_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
BEGIN;
INSERT INTO `sys_role` VALUES (1, '系统管理员', '2', 'admin', 1, '', '', 1, '', 1, 1, '2021-05-13 19:56:37.913', '2021-05-13 19:56:37.913');
COMMIT;

-- ----------------------------
-- Table structure for sys_role_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_dept`;
CREATE TABLE `sys_role_dept` (
  `role_id` smallint NOT NULL,
  `dept_id` smallint NOT NULL,
  PRIMARY KEY (`role_id`,`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_role_dept
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu` (
  `role_id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  PRIMARY KEY (`role_id`,`menu_id`),
  KEY `fk_sys_role_menu_sys_menu` (`menu_id`),
  CONSTRAINT `fk_sys_role_menu_sys_menu` FOREIGN KEY (`menu_id`) REFERENCES `sys_menu` (`menu_id`),
  CONSTRAINT `fk_sys_role_menu_sys_role` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_tables
-- ----------------------------
DROP TABLE IF EXISTS `sys_tables`;
CREATE TABLE `sys_tables` (
  `table_id` bigint NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `table_comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `tpl_category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `package_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `module_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `business_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `function_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `function_author` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `pk_column` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `pk_go_field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `pk_json_field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `options` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_plugin` tinyint(1) DEFAULT '0' COMMENT '是否插件0-否 1-是',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`table_id`),
  KEY `idx_sys_tables_create_by` (`create_by`),
  KEY `idx_sys_tables_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_tables
-- ----------------------------
BEGIN;
INSERT INTO `sys_tables` VALUES (46, 'content_category', '文章分类管理', 'Category', 'crud', 'content', 'category', 'category', '文章分类管理', 'Jason', 'id', 'Id', 'id', '', 1, '', '2022-04-17 02:17:29.935', '2022-04-18 13:40:47.504', 0, 0);
INSERT INTO `sys_tables` VALUES (47, 'content_article', '文章管理', 'Article', 'crud', 'content', 'article', 'article', '文章管理', 'Jason', 'id', 'Id', 'id', '', 1, '', '2022-04-18 17:19:51.552', '2022-04-18 17:23:20.843', 0, 0);
INSERT INTO `sys_tables` VALUES (48, 'content_announcement', '公告管理', 'Announcement', 'crud', 'content', 'announcement', 'announcement', '公告管理', 'Jason', 'id', 'Id', 'id', '', 1, '', '2022-04-19 17:19:31.536', '2022-04-19 17:30:38.790', 0, 0);
INSERT INTO `sys_tables` VALUES (49, 'filemgr_app', 'app升级管理', 'App', 'crud', 'filemgr', 'app', 'app', 'app升级管理', 'Jason', 'id', 'Id', 'id', '', 1, '', '2022-04-19 20:58:51.221', '2022-04-19 22:20:01.673', 0, 0);
INSERT INTO `sys_tables` VALUES (50, 'sys_api', ' 接口', 'Api', 'crud', 'sys', 'api', 'api', '接口', 'Jason', 'id', 'Id', 'id', '', 0, '', '2022-04-24 17:16:00.884', '2022-04-26 00:11:04.917', 0, 0);
INSERT INTO `sys_tables` VALUES (51, 'sys_dict_type', '字典类型', 'SysDictType', 'crud', 'sys', 'dicttype', 'dicttype', '字典类型', 'Jason', 'dict_id', 'DictId', 'dictId', '', 0, '', '2022-04-24 20:10:02.240', '2022-04-24 20:39:17.785', 0, 0);
INSERT INTO `sys_tables` VALUES (52, 'sys_dict_data', '字典数据', 'SysDictData', 'crud', 'sys', 'dictdata', 'dictdata', '字典数据', 'Jason', 'dict_code', 'DictCode', 'dictCode', '', 0, '', '2022-04-24 21:39:28.749', '2022-04-24 21:45:31.346', 0, 0);
INSERT INTO `sys_tables` VALUES (53, 'sys_config', '系统配置', 'Config', 'crud', 'sys', 'config', 'config', '系统配置', 'Jason', 'id', 'Id', 'id', '', 0, '', '2022-04-25 09:47:38.521', '2022-04-25 10:06:49.828', 0, 0);
INSERT INTO `sys_tables` VALUES (54, 'sys_login_log', '登陆日志', 'LoginLog', 'crud', 'sys', 'loginlog', 'loginlog', 'LoginLog', 'Jason', 'id', 'Id', 'id', '', 0, '', '2022-04-25 14:38:10.548', '2022-04-25 14:48:45.120', 0, 0);
INSERT INTO `sys_tables` VALUES (55, 'sys_opera_log', '操作日志', 'OperaLog', 'crud', 'sys', 'operalog', 'operalog', '操作日志', 'Jason', 'id', 'Id', 'id', '', 0, '', '2022-04-25 15:27:26.447', '2022-04-25 15:33:13.811', 0, 0);
INSERT INTO `sys_tables` VALUES (56, 'sys_post', '岗位', 'Post', 'crud', 'sys', 'post', 'post', '岗位', 'Jason', 'post_id', 'PostId', 'postId', '', 0, '', '2022-04-26 12:50:49.961', '2022-04-26 13:34:02.044', 0, 0);
INSERT INTO `sys_tables` VALUES (57, 'pha_worker', '文章管理', 'PhaWorker', 'crud', 'admin', 'phaWorker', 'phaWorker', '文章管理', 'Jason', 'id', 'Id', 'id', '', 1, '', '2022-04-28 21:26:17.687', '2022-04-28 21:26:17.687', 0, 0);
INSERT INTO `sys_tables` VALUES (58, 'pha_worker_log', '文章管理', 'PhaWorkerLog', 'crud', 'admin', 'phaWorkerLog', 'phaWorkerLog', '文章管理', 'Jason', 'id', 'Id', 'id', '', 1, '', '2022-04-28 21:26:19.000', '2022-04-28 21:26:19.000', 0, 0);
INSERT INTO `sys_tables` VALUES (59, 'pha_pool_record', '文章管理', 'PhaPoolRecord', 'crud', 'admin', 'phaPoolRecord', 'phaPoolRecord', '文章管理', 'Jason', 'id', 'Id', 'id', '', 1, '', '2022-04-28 21:26:21.177', '2022-04-28 21:26:21.177', 0, 0);
INSERT INTO `sys_tables` VALUES (60, 'pha_worker_dayliy_statistics', '文章管理', 'PhaWorkerDayliyStatistics', 'crud', 'admin', 'phaWorkerDayliyStatistics', 'phaWorkerDayliyStatistics', '文章管理', 'Jason', 'id', 'Id', 'id', '', 1, '', '2022-04-29 16:54:32.997', '2022-04-29 16:54:32.997', 0, 0);
COMMIT;

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT COMMENT '编码',
  `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用户名',
  `password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '密码',
  `nick_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '昵称',
  `phone` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '手机号',
  `role_id` bigint DEFAULT NULL COMMENT '角色ID',
  `salt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '加盐',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '头像',
  `sex` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '性别',
  `email` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '邮箱',
  `dept_id` bigint DEFAULT NULL COMMENT '部门',
  `post_id` bigint DEFAULT NULL COMMENT '岗位',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  `status` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '状态',
  `create_by` bigint DEFAULT NULL COMMENT '创建者',
  `update_by` bigint DEFAULT NULL COMMENT '更新者',
  `created_at` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime(3) DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`user_id`),
  KEY `idx_sys_user_create_by` (`create_by`),
  KEY `idx_sys_user_update_by` (`update_by`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
BEGIN;
INSERT INTO `sys_user` VALUES (1, 'admin', '$2a$10$Wmq8qyklDhsQLLqCFtM2SOeVeuoyoJaIW3i93FEVMizUAlXk83hWK', 'admin', '19111111111', 1, '', '/static/uploadfile/101b8e7e-bd36-468d-9dbc-4583f1842a04.jpg', '1', 'idea@ccc.cc2', 1, 1, '', '2', 1, 1, '2021-05-13 19:56:37.914', '2022-04-29 11:38:18.310');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
